extends Node
# UI flow + menus (all built in code so no .tscn editing is needed).
const Builder = preload("res://scripts/Builder.gd")
const MapView = preload("res://scripts/MapView.gd")
const ABIL := {"none": "সাধারণ", "passive_magnet": "ছোট ম্যাগনেট সবসময়", "long_powerup": "পাওয়ার-আপ ১.৫x সময়",
	"start_shield": "শুরুতে শিল্ড"}
var layer: CanvasLayer
var stage: Node3D
var cam: Camera3D
var preview: Node3D
var run = null
var hud := {}
var gender_tab := "boy"
var cur_char := ""
var banked := false
var settings_back: Callable
var confirm_reset := false
var _t := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	settings_back = show_menu
	_build_stage()
	layer = CanvasLayer.new()
	add_child(layer)
	_clear()
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(cc)
	var sv := VBoxContainer.new()
	cc.add_child(sv)
	_logo(sv, 460.0)
	var ttl := _lbl(sv, "বাঘ এক্সপ্রেস", 40)
	ttl.add_theme_color_override("font_color", Color(1, 0.85, 0.25))
	_lbl(sv, "BAGH EXPRESS  •  3D Route Runner", 20)
	_lbl(sv, "ডেভলপার: Medul", 22)
	await get_tree().create_timer(1.8).timeout
	show_menu()

func _logo(parent: Node, size: float) -> void:
	var p := "res://icons/logo.png"
	if ResourceLoader.exists(p):
		var t := TextureRect.new()
		t.texture = load(p)
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		t.custom_minimum_size = Vector2(size, size)
		parent.add_child(t)

func _process(dt: float) -> void:
	if preview != null and preview.visible:
		_t += dt
		preview.rotation.y = PI + sin(_t * 0.8) * 0.9
	if run != null and hud.has("score") and run.alive:
		var i: Dictionary = run.info()
		hud["score"].text = "স্কোর: %d" % int(i["score"])
		hud["dist"].text = "%.1f / %d KM" % [float(i["km"]), int(i["total_km"])]
		hud["coins"].text = "কয়েন: %d" % int(i["coins"])
		hud["pu"].text = str(i["pu"])
		hud["bar"].value = float(i["km"]) / float(i["total_km"]) * 100.0
		if hud.has("sec"):
			hud["sec"].text = Game.t("এখন: %s → পরের: %s (%.0f কিমি)") % [str(i["sec"]), str(i["next"]), float(i["next_km"])]
			var hv: bool = bool(i["has_veh"])
			hud["veh"].text = ("%s: %s" % [Game.t("গাড়ি"), str(i["veh"])]) if hv else Game.t("পায়ে হেঁটে")
			hud["fuel"].visible = hv and float(i["burn"]) > 0.0
			hud["fuel"].value = float(i["fuel"])
			hud["pump"].visible = bool(i["pump"])
			hud["spd"].text = "%s %d %s  x%.1f" % [Game.t("গতি"), int(i["kmh"]), Game.t("কিমি/ঘ"), float(i["thr"])]
			hud["warn"].text = Game.t("বাঘ কাছে!") if bool(i["tiger_near"]) else ""
			hud["pump"].text = Game.t("পেট্রোল নিন") + "  -%d %s  (+%d%%)" % [int(i["pump_cost"]), Game.t("কয়েন"), int(i["pump_gain"])]

# ---------------- helpers ----------------
func _build_stage() -> void:
	stage = Node3D.new()
	add_child(stage)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.45, 0.75, 1.0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.8, 0.85, 0.9)
	var we := WorldEnvironment.new()
	we.environment = env
	stage.add_child(we)
	var l := DirectionalLight3D.new()
	l.rotation_degrees = Vector3(-45, -30, 0)
	stage.add_child(l)
	Builder.cyl(stage, 3.0, 3.0, 0.2, Vector3(0, -0.1, 0), Color(0.3, 0.6, 0.3))
	cam = Camera3D.new()
	stage.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.5, 4.6), Vector3(0, 0.62, 0))

func _set_preview(id: String) -> void:
	if preview != null:
		preview.queue_free()
	preview = Builder.make_character(Game.char_by_id(id))
	preview.position = Vector3(0, 0, 0)
	stage.add_child(preview)

func _clear() -> void:
	hud.clear()
	for c in layer.get_children():
		c.queue_free()

func _lbl(parent: Node, t: String, size: int = 22) -> Label:
	var l := Label.new()
	l.text = Game.t(t)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	parent.add_child(l)
	return l

func _sbox(c: Color, lift: float = 0.0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = c.lightened(lift)
	sb.set_corner_radius_all(18)
	sb.border_width_bottom = 5
	sb.border_color = c.darkened(0.4)
	sb.shadow_color = Color(0, 0, 0, 0.35)
	sb.shadow_size = 6
	sb.set_content_margin_all(8)
	return sb

func _style_btn(b: Button, c: Color) -> void:
	b.add_theme_stylebox_override("normal", _sbox(c))
	b.add_theme_stylebox_override("hover", _sbox(c, 0.12))
	var pr := _sbox(c, 0.2)
	pr.border_width_bottom = 1
	b.add_theme_stylebox_override("pressed", pr)
	b.add_theme_stylebox_override("focus", _sbox(c, 0.05))
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
	b.add_theme_constant_override("outline_size", 4)

func _press_anim(b: Button, down: bool) -> void:
	if not is_instance_valid(b):
		return
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2.ONE * (0.92 if down else 1.0), 0.07)

func _click_fx() -> void:
	Game.sfx("click", -3.0)

func _btn(parent: Node, t: String, cb: Callable, h: int = 58, col: Color = Color(0.17, 0.4, 0.66)) -> Button:
	var b := Button.new()
	b.text = Game.t(t)
	b.custom_minimum_size = Vector2(0, h)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 22)
	var c := col
	if t.begins_with("ফিরে যান"):
		c = Color(0.36, 0.4, 0.5)
	elif t.begins_with("খেলুন"):
		c = Color(0.98, 0.55, 0.08)
	_style_btn(b, c)
	b.resized.connect(func(): b.pivot_offset = b.size / 2.0)
	b.button_down.connect(_press_anim.bind(b, true))
	b.button_up.connect(_press_anim.bind(b, false))
	b.pressed.connect(_click_fx)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b

func _screen(title: String, top: float = 0.08, show_char: bool = false) -> VBoxContainer:
	_clear()
	if preview != null:
		preview.visible = show_char
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.1, 0.18, 0.82)
	sb.set_corner_radius_all(24)
	sb.set_content_margin_all(18)
	pc.add_theme_stylebox_override("panel", sb)
	pc.anchor_left = 0.04
	pc.anchor_right = 0.96
	pc.anchor_top = top
	pc.anchor_bottom = 0.97
	pc.grow_vertical = Control.GROW_DIRECTION_BEGIN
	layer.add_child(pc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	pc.add_child(v)
	_lbl(v, title, 32)
	return v

func _toast(t: String) -> void:
	var l := _lbl(layer, t, 26)
	l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	l.position.y = 140
	l.custom_minimum_size = Vector2(500, 0)
	l.position.x = 20
	get_tree().create_timer(2.0).timeout.connect(l.queue_free)

# ---------------- menus ----------------
func _chip(parent: Node, text: String, col: Color) -> void:
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(6)
	pc.add_theme_stylebox_override("panel", sb)
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(pc)
	_lbl(pc, text, 19)

func _bob(n: Control, amp: float = 6.0) -> void:
	var tw := n.create_tween().set_loops()
	tw.tween_property(n, "position:y", n.position.y - amp, 0.8).set_trans(Tween.TRANS_SINE)
	tw.tween_property(n, "position:y", n.position.y + amp, 0.8).set_trans(Tween.TRANS_SINE)

func show_menu() -> void:
	_set_preview(Game.save["selected"])
	var v := _screen("বাঘ এক্সপ্রেস", 0.45, true)
	var title: Label = v.get_child(0)
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(1, 0.85, 0.25))
	var tw := title.create_tween().set_loops()
	tw.tween_property(title, "modulate", Color(1, 1, 1, 0.75), 0.9)
	tw.tween_property(title, "modulate", Color(1, 1, 1, 1), 0.9)
	_logo(layer, 110.0)
	var r := Game.route_data()
	_lbl(v, "%s → %s" % [Game.nm(r["from_d"]), Game.nm(r["to_d"])], 22)
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 8)
	v.add_child(chips)
	_chip(chips, "%s: %d" % [Game.t("কয়েন"), int(Game.save["coins"])], Color(0.55, 0.4, 0.05, 0.9))
	_chip(chips, "%s: %d" % [Game.t("রিভাইভ টোকেন"), int(Game.save["tokens"])], Color(0.6, 0.12, 0.3, 0.9))
	_chip(chips, "%s: %d" % [Game.t("সেরা স্কোর"), int(Game.save["best_score"])], Color(0.1, 0.4, 0.3, 0.9))
	var play := _btn(v, "খেলুন / PLAY", start_run, 64)
	play.add_theme_font_size_override("font_size", 30)
	var pt := play.create_tween().set_loops()
	pt.tween_property(play, "scale", Vector2.ONE * 1.035, 0.7).set_trans(Tween.TRANS_SINE)
	pt.tween_property(play, "scale", Vector2.ONE, 0.7).set_trans(Tween.TRANS_SINE)
	var g := GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 10)
	g.add_theme_constant_override("v_separation", 10)
	v.add_child(g)
	_btn(g, "চরিত্র", show_characters, 50, Color(0.5, 0.3, 0.75))
	_btn(g, "মানচিত্র / MAP", show_map, 50, Color(0.2, 0.5, 0.85))
	_btn(g, "মিশন", show_missions, 50, Color(0.2, 0.6, 0.35))
	_btn(g, "শপ", show_shop, 50, Color(0.85, 0.3, 0.5))
	_btn(g, "ক্লাউড / লিডারবোর্ড", show_cloud, 50, Color(0.15, 0.55, 0.6))
	_btn(g, "সেটিংস", show_settings, 50, Color(0.4, 0.45, 0.55))
	_lbl(v, "ডেভলপার: Medul", 16)

func _set_mode(on: bool) -> void:
	Game.save["settings"]["online"] = on
	Game.write_save()
	show_menu()
	if on and CloudSync.online_enabled():
		CloudSync.sync()
	elif on:
		_toast("ক্লাউড মেনুতে Cloud URL দিন")

func _pick(id: String) -> void:
	cur_char = id
	show_characters()

func _tab(g: String) -> void:
	gender_tab = g
	cur_char = ""
	show_characters()

func _select(id: String) -> void:
	Game.save["selected"] = id
	Game.write_save()
	show_characters()

func _unlock(id: String) -> void:
	if Game.unlock(id):
		Game.save["selected"] = id
		Game.write_save()
		show_characters()
	else:
		_toast("কয়েন কম আছে!")

func show_characters() -> void:
	var chars: Array = []
	for c in Game.characters:
		if c["gender"] == gender_tab:
			chars.append(c)
	if cur_char == "" or Game.char_by_id(cur_char)["gender"] != gender_tab:
		cur_char = chars[0]["id"]
	_set_preview(cur_char)
	var v := _screen("চরিত্র নির্বাচন", 0.46, true)
	var tabs := HBoxContainer.new()
	v.add_child(tabs)
	_btn(tabs, "ছেলে BOYS", _tab.bind("boy"), 50)
	_btn(tabs, "মেয়ে GIRLS", _tab.bind("girl"), 50)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 62)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var hb := HBoxContainer.new()
	sc.add_child(hb)
	for c in chars:
		_btn(hb, Game.nm(c), _pick.bind(str(c["id"])), 54)
	var cd: Dictionary = Game.char_by_id(cur_char)
	_lbl(v, "%s — %s — দাম: %d COIN" % [Game.nm(cd), ABIL.get(cd["ability"], ""), int(cd["price"])], 18)
	if Game.is_unlocked(cur_char):
		if Game.save["selected"] == cur_char:
			_lbl(v, "নির্বাচিত (SELECTED)", 22)
		else:
			_btn(v, "নির্বাচন (SELECT)", _select.bind(cur_char))
	else:
		_btn(v, "আনলক (UNLOCK) — %d COIN" % int(cd["price"]), _unlock.bind(cur_char))
	_btn(v, "ফিরে যান", show_menu, 50)

func _flip_dir() -> void:
	Game.save["direction"] = "rev" if Game.save["direction"] == "fwd" else "fwd"
	Game.write_save()
	show_map()

func _open_gmaps() -> void:
	var r := Game.route_data()
	var o := "Jhenaidah,Bangladesh"
	var d := "Phulbari+Railway+Station,Dinajpur,Bangladesh"
	if r["dir"] == "rev":
		var t := o
		o = d
		d = t
	OS.shell_open("https://www.google.com/maps/dir/?api=1&origin=%s&destination=%s&travelmode=driving" % [o, d])

func show_map() -> void:
	var v := _screen("মানচিত্র / ROUTE MAP", 0.03)
	var r := Game.route_data()
	var reached: int = int(Game.save["progress"].get(r["dir"], 0))
	var stops: Array = r["stops"]
	_btn(v, "দিক বদলান: %s → %s" % [Game.nm(r["from_d"]), Game.nm(r["to_d"])], _flip_dir, 46)
	var mv := Control.new()
	mv.set_script(MapView)
	mv.setup(r, reached, Game.is_en())
	mv.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(mv)
	_lbl(v, "%d কিমি (আনুমানিক) — %s" % [int(r["length_km"]), Game.nm(r["from_d"]) + " → " + Game.nm(r["to_d"])], 16)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 120)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var lv := VBoxContainer.new()
	lv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(lv)
	for i in stops.size():
		var mark := "●" if i <= reached else "○"
		var st: Dictionary = stops[i]
		var kind: String = str(st.get("kind", "town"))
		var tag := ""
		if i == 0: tag = "  (START)"
		elif i == stops.size() - 1: tag = "  (DESTINATION)"
		var line := "%s  %s  —  %d KM%s" % [mark, Game.nm(st), int(st["at"]), tag]
		var l := _lbl(lv, line, 16 if kind == "town" else 14)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	var hb := HBoxContainer.new()
	v.add_child(hb)
	_btn(hb, "গুগল ম্যাপে খুলুন", _open_gmaps, 46)
	_btn(hb, "ফিরে যান", show_menu, 46)

func show_missions() -> void:
	var v := _screen("মিশন")
	var s: Dictionary = Game.save["stats"]
	for m in Game.missions:
		var done: bool = m["id"] in Game.save["claimed"]
		_lbl(v, "%s  [%d/%d]  %s" % [str(m["en"]) if Game.is_en() else str(m["text"]), mini(int(s.get(m["type"], 0)), int(m["target"])), int(m["target"]), "সম্পন্ন" if done else "পুরস্কার %d কয়েন" % int(m["reward"])], 20)
	_btn(v, "ফিরে যান", show_menu)

func show_shop() -> void:
	var v := _screen("শপ")
	_lbl(v, "কয়েন: %d    রিভাইভ টোকেন: %d" % [int(Game.save["coins"]), int(Game.save["tokens"])], 24)
	_lbl(v, "রিভাইভ টোকেন রাস্তায় হার্ট কুড়িয়ে পাওয়া যায়, দোকানে কেনা যায় না", 18)
	_lbl(v, "মিশনে পুরস্কার পাওয়া যায়", 18)
	_btn(v, "চরিত্র", show_characters, 64, Color(0.5, 0.3, 0.75))
	_btn(v, "মিশন", show_missions, 64, Color(0.2, 0.6, 0.35))
	_btn(v, "ফিরে যান", show_menu)

func _toggle(v: Node, label: String, key: String) -> void:
	var st: Dictionary = Game.save["settings"]
	_btn(v, "%s: %s" % [label, "ON" if st[key] else "OFF"], _flip.bind(key), 52)

func _flip(key: String) -> void:
	var st: Dictionary = Game.save["settings"]
	st[key] = not st[key]
	Game.write_save()
	if key == "music":
		Game.music_apply()
	show_settings()

func _cycle_q() -> void:
	var st: Dictionary = Game.save["settings"]
	st["quality"] = (int(st["quality"]) + 1) % 4
	Game.write_save()
	show_settings()

func _cycle_fps() -> void:
	var st: Dictionary = Game.save["settings"]
	st["fps"] = 30 if int(st["fps"]) == 60 else 60
	Game.apply_settings()
	Game.write_save()
	show_settings()

func _cycle_lang() -> void:
	var st: Dictionary = Game.save["settings"]
	st["lang"] = "en" if st["lang"] == "bn" else "bn"
	Game.write_save()
	show_settings()
	_set_preview(Game.save["selected"])

func _reset() -> void:
	if confirm_reset:
		Game.reset_all()
		confirm_reset = false
		show_menu()
	else:
		confirm_reset = true
		show_settings()

func show_settings() -> void:
	var v := _screen("সেটিংস")
	var st: Dictionary = Game.save["settings"]
	_toggle(v, "Music", "music")
	_toggle(v, "Sound", "sound")
	_toggle(v, "Vibration", "vibration")
	_toggle(v, "Online mode", "online")
	_btn(v, "Graphics: %s" % ["LOW", "MEDIUM", "HIGH", "ULTRA"][int(st["quality"])], _cycle_q, 52)
	_btn(v, "FPS: %d" % int(st["fps"]), _cycle_fps, 52)
	_btn(v, "ভাষা / Language:  %s" % ("English" if Game.is_en() else "বাংলা"), _cycle_lang, 52)
	_btn(v, "ক্লাউড সেভ মেনু", show_cloud, 52)
	_btn(v, "নিশ্চিত? আবার চাপুন" if confirm_reset else "Reset Local Data", _reset, 52)
	_btn(v, "ফিরে যান", settings_back, 52)

func _cloud_sync() -> void:
	await CloudSync.sync()
	show_cloud()

func _cloud_restore() -> void:
	await CloudSync.restore()
	show_cloud()

func _local_backup() -> void:
	Game.backup_local()
	CloudSync.status = "লোকাল ব্যাকআপ নেওয়া হয়েছে"
	show_cloud()

func _local_restore() -> void:
	CloudSync.status = "লোকাল ব্যাকআপ থেকে রিস্টোর হয়েছে" if Game.restore_local() else "ব্যাকআপ পাওয়া যায়নি"
	show_cloud()

func _set_url(t: String) -> void:
	Game.save["settings"]["cloud_url"] = t
	Game.write_save()

func _set_name(t: String) -> void:
	Game.save["settings"]["name"] = t
	Game.write_save()

func _lb() -> void:
	show_leaderboard()

func show_cloud() -> void:
	var v := _screen("ক্লাউড / অনলাইন")
	var on: bool = bool(Game.save["settings"]["online"])
	_lbl(v, "মোড: %s — অফলাইনে সব কাজ করে। অনলাইনে ক্লাউড সেভ ও লিডারবোর্ড।" % ("অনলাইন" if on else "অফলাইন"), 18)
	var ne := LineEdit.new()
	ne.placeholder_text = Game.t("আপনার নাম")
	ne.text = str(Game.save["settings"]["name"])
	ne.text_changed.connect(_set_name)
	v.add_child(ne)
	var le := LineEdit.new()
	le.placeholder_text = "Cloud URL (https://...firebaseio.com)"
	le.text = str(Game.save["settings"]["cloud_url"])
	le.text_changed.connect(_set_url)
	v.add_child(le)
	_btn(v, "এখন সিঙ্ক করুন (LOCAL → CLOUD)", _cloud_sync, 50)
	_btn(v, "ক্লাউড থেকে রিস্টোর", _cloud_restore, 50)
	_btn(v, "লিডারবোর্ড দেখুন", _lb, 50)
	_btn(v, "লোকাল ব্যাকআপ নিন", _local_backup, 46)
	_btn(v, "লোকাল ব্যাকআপ থেকে রিস্টোর", _local_restore, 46)
	_lbl(v, CloudSync.status, 18)
	_btn(v, "ফিরে যান", show_menu, 46)

func show_leaderboard() -> void:
	var v := _screen("লিডারবোর্ড")
	if not CloudSync.online_enabled():
		_lbl(v, "অনলাইন মোড চালু করুন এবং ক্লাউড URL দিন।", 20)
		_btn(v, "ফিরে যান", show_cloud, 50)
		return
	_lbl(v, "লোড হচ্ছে...", 20)
	var rows: Array = await CloudSync.fetch_scores()
	v = _screen("লিডারবোর্ড")
	if rows.is_empty():
		_lbl(v, CloudSync.status, 20)
	var i := 1
	for e in rows:
		_lbl(v, "%d. %s — %d" % [i, str(e["name"]), int(e["best"])], 22)
		i += 1
	_btn(v, "ফিরে যান", show_cloud, 50)

# ---------------- run flow ----------------
func start_run() -> void:
	_stop_run()
	if stage.get_parent() != null:
		remove_child(stage)
	banked = false
	run = load("res://scripts/Run.gd").new()
	add_child(run)
	run.died.connect(_on_died)
	run.finished.connect(_on_finished)
	run.toast.connect(_toast)
	_build_hud()

func _stop_run() -> void:
	get_tree().paused = false
	if run != null:
		run.queue_free()
		run = null
	hud.clear()
	if stage.get_parent() == null:
		add_child(stage)
		cam.make_current()

func _build_hud() -> void:
	_clear()
	var m := MarginContainer.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 14)
	layer.add_child(m)
	var v := VBoxContainer.new()
	m.add_child(v)
	var top := HBoxContainer.new()
	v.add_child(top)
	hud["score"] = _lbl(top, "", 22)
	hud["score"].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud["dist"] = _lbl(top, "", 22)
	hud["dist"].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var pb := _btn(top, "II", _pause, 44)
	pb.custom_minimum_size = Vector2(60, 44)
	pb.size_flags_horizontal = Control.SIZE_SHRINK_END
	hud["bar"] = ProgressBar.new()
	hud["bar"].show_percentage = false
	hud["bar"].custom_minimum_size = Vector2(0, 10)
	v.add_child(hud["bar"])
	var row := HBoxContainer.new()
	v.add_child(row)
	hud["coins"] = _lbl(row, "", 22)
	hud["coins"].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud["pu"] = _lbl(row, "", 20)
	hud["pu"].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud["spd"] = _lbl(row, "", 18)
	hud["spd"].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud["warn"] = _lbl(v, "", 26)
	hud["warn"].add_theme_color_override("font_color", Color(1, 0.3, 0.25))
	hud["sec"] = _lbl(v, "", 18)
	hud["veh"] = _lbl(v, "", 20)
	hud["fuel"] = ProgressBar.new()
	hud["fuel"].show_percentage = false
	hud["fuel"].custom_minimum_size = Vector2(0, 14)
	hud["fuel"].visible = false
	v.add_child(hud["fuel"])
	var ctl := HBoxContainer.new()
	ctl.anchor_left = 0.02
	ctl.anchor_right = 0.98
	ctl.anchor_top = 1.0
	ctl.anchor_bottom = 1.0
	ctl.offset_top = -104.0
	ctl.offset_bottom = -18.0
	ctl.add_theme_constant_override("separation", 8)
	layer.add_child(ctl)
	_hud_btn(ctl, "−", Color(0.35, 0.4, 0.5), func(): _run_call("throttle_add", -0.15), 1.0)
	var brake := _hud_btn(ctl, "ব্রেক", Color(0.8, 0.2, 0.2), Callable(), 1.6)
	brake.button_down.connect(func(): _run_call("set_brake", true))
	brake.button_up.connect(func(): _run_call("set_brake", false))
	_hud_btn(ctl, "হর্ন", Color(0.95, 0.65, 0.1), func(): _run_call("horn"), 1.4)
	_hud_btn(ctl, "চড়", Color(0.85, 0.3, 0.55), func(): _run_call("slap"), 1.4)
	_hud_btn(ctl, "+", Color(0.2, 0.6, 0.4), func(): _run_call("throttle_add", 0.15), 1.0)
	var pump := Button.new()
	pump.add_theme_font_size_override("font_size", 24)
	pump.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	pump.anchor_left = 0.08
	pump.anchor_right = 0.92
	pump.anchor_top = 1.0
	pump.anchor_bottom = 1.0
	pump.offset_top = -190.0
	pump.offset_bottom = -116.0
	_style_btn(pump, Color(0.1, 0.55, 0.3))
	pump.visible = false
	pump.pressed.connect(_buy_fuel)
	layer.add_child(pump)
	hud["pump"] = pump

func _run_call(fn: String, arg: Variant = null) -> void:
	if run == null or not is_instance_valid(run):
		return
	if arg == null:
		run.call(fn)
	else:
		run.call(fn, arg)

func _hud_btn(parent: Node, t: String, col: Color, cb: Callable, weight: float) -> Button:
	var b := Button.new()
	b.text = Game.t(t)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_stretch_ratio = weight
	b.custom_minimum_size = Vector2(0, 84)
	b.add_theme_font_size_override("font_size", 24)
	b.focus_mode = Control.FOCUS_NONE
	_style_btn(b, col)
	b.resized.connect(func(): b.pivot_offset = b.size / 2.0)
	b.button_down.connect(_press_anim.bind(b, true))
	b.button_up.connect(_press_anim.bind(b, false))
	b.button_down.connect(_click_fx)
	if cb.is_valid():
		b.pressed.connect(cb)
	parent.add_child(b)
	return b

func _buy_fuel() -> void:
	if run != null:
		run.buy_fuel()

func _pause() -> void:
	get_tree().paused = true
	var v := _screen("বিরতি / PAUSE", 0.25)
	_btn(v, "চালিয়ে যান / RESUME", _resume, 60)
	_btn(v, "আবার শুরু / RESTART", _restart, 60)
	_btn(v, "MAP", _to_map, 60)
	_btn(v, "SETTINGS", _pause_settings, 60)
	_btn(v, "MAIN MENU", _home, 60)

func _pause_settings() -> void:
	settings_back = _pause
	show_settings()

func _resume() -> void:
	settings_back = show_menu
	get_tree().paused = false
	_build_hud()

func _bank(completed: bool, st: Dictionary) -> Array:
	if banked:
		return []
	banked = true
	var done := Game.end_run(st, completed)
	if CloudSync.online_enabled():
		CloudSync.sync()
	return done

func _restart() -> void:
	if run != null:
		_bank(false, run.stats())
	settings_back = show_menu
	start_run()

func _to_map() -> void:
	if run != null:
		_bank(false, run.stats())
	_stop_run()
	settings_back = show_menu
	show_map()

func _home() -> void:
	if run != null:
		_bank(false, run.stats())
	_stop_run()
	settings_back = show_menu
	show_menu()

func _on_died(st: Dictionary) -> void:
	var v := _screen("GAME OVER", 0.22)
	_lbl(v, "স্কোর: %d    দূরত্ব: %.1f KM" % [int(st["score"]), float(st["km"])], 24)
	_lbl(v, "কয়েন: %d    চেকপয়েন্ট: %d    সেরা: %d" % [int(st["coins"]), int(st["cps"]), maxi(int(Game.save["best_score"]), int(st["score"]))], 20)
	_btn(v, "RETRY", _restart, 60)
	if int(Game.save["tokens"]) > 0:
		_btn(v, "REVIVE (টোকেন: %d)" % int(Game.save["tokens"]), _revive, 60)
	_btn(v, "MAP", _to_map, 60)
	_btn(v, "HOME", _home, 60)

func _revive() -> void:
	Game.save["tokens"] = int(Game.save["tokens"]) - 1
	Game.write_save()
	run.revive()
	_build_hud()

func _next_route() -> void:
	_flip_dir_silent()
	start_run()

func _flip_dir_silent() -> void:
	Game.save["direction"] = "rev" if Game.save["direction"] == "fwd" else "fwd"
	Game.write_save()

func _on_finished(st: Dictionary) -> void:
	var done := _bank(true, st)
	var v := _screen("JOURNEY COMPLETE!", 0.15)
	var r := Game.route_data()
	_lbl(v, "গন্তব্য: %s" % Game.nm(r["to_d"]), 26)
	_lbl(v, "দূরত্ব: %.0f KM    কয়েন: %d" % [float(st["km"]), int(st["coins"])], 22)
	_lbl(v, "স্কোর: %d    সময়: %d সেকেন্ড" % [int(st["score"]), int(st["time"])], 22)
	_lbl(v, "সেরা স্কোর: %d    পুরস্কার: +50 কয়েন" % int(Game.save["best_score"]), 20)
	for m in done:
		_lbl(v, "মিশন সম্পন্ন: %s (+%d)" % [str(m["en"]) if Game.is_en() else str(m["text"]), int(m["reward"])], 18)
	_btn(v, "NEXT ROUTE (উল্টো দিক)", _next_route, 60)
	_btn(v, "REPLAY", _restart, 60)
	_btn(v, "MAIN MENU", _home, 60)
