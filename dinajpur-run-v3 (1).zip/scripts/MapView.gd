extends Control
# Google-Maps-style route map (drawn in code, works offline). Town coordinates are real; roads are schematic.
const LAT0 := 23.40
const LAT1 := 25.85
const LON0 := 88.40
const LON1 := 89.80
const LAND := Color(0.953, 0.941, 0.914)
const WATER := Color(0.667, 0.855, 1.0)
const PARK := Color(0.78, 0.9, 0.78)
const ROUTE := Color(0.259, 0.522, 0.957)
const DONE := Color(0.62, 0.7, 0.82)
const TXT := Color(0.24, 0.26, 0.29)

# bn, en, lat, lon  (context cities, grey like Google Maps)
const CITIES := [
	["রাজশাহী", "Rajshahi", 24.37, 88.60], ["পাবনা", "Pabna", 24.00, 89.25], ["রংপুর", "Rangpur", 25.75, 89.25],
	["জয়পুরহাট", "Joypurhat", 25.10, 89.03], ["নওগাঁ", "Naogaon", 24.80, 88.93], ["সিরাজগঞ্জ", "Sirajganj", 24.45, 89.70],
	["গাইবান্ধা", "Gaibandha", 25.33, 89.54], ["দিনাজপুর", "Dinajpur", 25.63, 88.65], ["চুয়াডাঙ্গা", "Chuadanga", 23.64, 88.85],
	["মাগুরা", "Magura", 23.49, 89.42], ["যশোর", "Jashore", 23.17, 89.21]]
const PADMA := [[24.65, 88.25], [24.40, 88.55], [24.18, 88.85], [24.07, 89.03], [23.97, 89.30], [23.88, 89.58], [23.80, 89.80]]

var route: Dictionary = {}
var reached := 0
var en := false
var pulse := 0.0
var pts: Array = []   # [{pos:Vector2, name, km, kind, i}]
var _labels: Array = []
var _built_size := Vector2.ZERO

func setup(r: Dictionary, reached_idx: int, english: bool) -> void:
	route = r
	reached = reached_idx
	en = english
	custom_minimum_size = Vector2(0, 430)
	clip_contents = true

func _process(dt: float) -> void:
	pulse = fposmod(pulse + dt * 0.9, 1.0)
	queue_redraw()

func _proj(lat: float, lon: float) -> Vector2:
	var k := cos(deg_to_rad(24.5))
	var sx: float = size.x / ((LON1 - LON0) * k)
	var sy: float = size.y / (LAT1 - LAT0)
	var sc: float = minf(sx, sy)
	var w: float = (LON1 - LON0) * k * sc
	var h: float = (LAT1 - LAT0) * sc
	var ox: float = (size.x - w) / 2.0
	var oy: float = (size.y - h) / 2.0
	return Vector2(ox + (lon - LON0) * k * sc, oy + (LAT1 - lat) * sc)

func _build_points() -> void:
	pts.clear()
	var stops: Array = route["stops"]
	var towns: Array = []
	for i in stops.size():
		if stops[i].has("lat"):
			towns.append(i)
	for i in stops.size():
		var st: Dictionary = stops[i]
		var lat: float
		var lon: float
		if st.has("lat"):
			lat = float(st["lat"])
			lon = float(st["lon"])
		else:
			var a: Dictionary = stops[towns[0]]
			var b: Dictionary = stops[towns[towns.size() - 1]]
			for j in towns.size() - 1:
				if float(stops[towns[j]]["at"]) <= float(st["at"]) and float(stops[towns[j + 1]]["at"]) >= float(st["at"]):
					a = stops[towns[j]]
					b = stops[towns[j + 1]]
					break
			var t: float = (float(st["at"]) - float(a["at"])) / maxf(float(b["at"]) - float(a["at"]), 0.001)
			lat = lerpf(float(a["lat"]), float(b["lat"]), t)
			lon = lerpf(float(a["lon"]), float(b["lon"]), t)
		pts.append({"pos": _proj(lat, lon), "name": Game.nm(st), "km": float(st["at"]), "kind": str(st.get("kind", "town")), "i": i})

func _label(text: String, p: Vector2, size_px: int, col: Color, bold: bool, left: bool) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(1, 1, 1, 0.95))
	l.add_theme_constant_override("outline_size", 5)
	add_child(l)
	var ms := l.get_minimum_size()
	l.size = ms
	l.position = Vector2(p.x - ms.x - 12.0, p.y - ms.y / 2.0) if left else Vector2(p.x + 12.0, p.y - ms.y / 2.0)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_labels.append(l)

func _rebuild_labels() -> void:
	for l in _labels:
		l.queue_free()
	_labels.clear()
	_build_points()
	for c in CITIES:
		var p: Vector2 = _proj(float(c[2]), float(c[3]))
		_label(str(c[1]) if en else str(c[0]), p, 13, Color(0.45, 0.47, 0.5), false, p.x > size.x * 0.62)
	var pr: Vector2 = _proj(24.20, 88.82)
	_label("Padma River" if en else "পদ্মা নদী", pr + Vector2(-70, -14), 13, Color(0.2, 0.45, 0.75), false, false)
	for p in pts:
		if str(p["kind"]) != "town":
			continue
		var pos: Vector2 = p["pos"]
		_label(str(p["name"]), pos, 16, TXT, true, pos.x > size.x * 0.55)
	_built_size = size

func _draw() -> void:
	if route.is_empty() or size.x < 10.0:
		return
	if _built_size != size:
		_rebuild_labels()
	draw_rect(Rect2(Vector2.ZERO, size), LAND)
	# parks / farmland patches
	for pk in [[24.7, 88.7, 38], [25.35, 88.95, 30], [23.7, 89.3, 34], [24.2, 89.55, 26], [25.5, 89.4, 28]]:
		draw_circle(_proj(float(pk[0]), float(pk[1])), float(pk[2]), PARK)
	# Padma river
	var rv := PackedVector2Array()
	for q in PADMA:
		rv.append(_proj(float(q[0]), float(q[1])))
	draw_polyline(rv, WATER.darkened(0.03), 20.0, true)
	draw_polyline(rv, WATER, 15.0, true)
	# route (casing + colour), passed part greyed
	var all := PackedVector2Array()
	for p in pts:
		all.append(p["pos"])
	draw_polyline(all, Color.WHITE, 13.0, true)
	var done := PackedVector2Array()
	var rest := PackedVector2Array()
	for p in pts:
		if int(p["i"]) <= reached:
			done.append(p["pos"])
		if int(p["i"]) >= reached:
			rest.append(p["pos"])
	if rest.size() > 1:
		draw_polyline(rest, ROUTE, 8.0, true)
	if done.size() > 1:
		draw_polyline(done, DONE, 8.0, true)
	# stops
	for p in pts:
		var pos: Vector2 = p["pos"]
		if str(p["kind"]) == "town":
			draw_circle(pos, 8.5, Color.WHITE)
			draw_circle(pos, 6.0, ROUTE if int(p["i"]) > reached else DONE)
		else:
			draw_circle(pos, 4.0, Color.WHITE)
			draw_circle(pos, 2.5, Color(0.5, 0.55, 0.62))
	# start (green) and destination (red pin)
	var sp: Vector2 = pts[0]["pos"]
	draw_circle(sp, 12.0, Color.WHITE)
	draw_circle(sp, 9.0, Color(0.2, 0.66, 0.33))
	var ep: Vector2 = pts[pts.size() - 1]["pos"]
	draw_colored_polygon(PackedVector2Array([ep + Vector2(-9, -22), ep + Vector2(9, -22), ep]), Color(0.92, 0.26, 0.21))
	draw_circle(ep + Vector2(0, -26), 13.0, Color(0.92, 0.26, 0.21))
	draw_circle(ep + Vector2(0, -26), 5.0, Color.WHITE)
	# "you are here" blue dot with pulsing halo
	var me: Vector2 = pts[clampi(reached, 0, pts.size() - 1)]["pos"]
	draw_circle(me, 10.0 + pulse * 22.0, Color(0.26, 0.52, 0.96, 0.35 * (1.0 - pulse)))
	draw_circle(me, 10.0, Color.WHITE)
	draw_circle(me, 7.0, Color(0.1, 0.45, 0.95))
	# scale bar (50 km) + compass N
	var k := cos(deg_to_rad(24.5))
	var sc: float = minf(size.x / ((LON1 - LON0) * k), size.y / (LAT1 - LAT0))
	var px50: float = sc * (50.0 / 111.0)
	var b0 := Vector2(14, size.y - 16)
	draw_line(b0, b0 + Vector2(px50, 0), TXT, 3.0)
	draw_line(b0 + Vector2(0, -5), b0 + Vector2(0, 5), TXT, 2.0)
	draw_line(b0 + Vector2(px50, -5), b0 + Vector2(px50, 5), TXT, 2.0)
	draw_colored_polygon(PackedVector2Array([Vector2(size.x - 26, 14), Vector2(size.x - 18, 38), Vector2(size.x - 34, 38)]), Color(0.85, 0.25, 0.2))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.8, 0.8, 0.8), false, 2.0)
