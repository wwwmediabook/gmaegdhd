extends RefCounted
# Nicer procedural models: vehicles (taxi, car, CNG, rickshaw, bike, bus), animals, petrol pump, toll plaza.
# Front of every vehicle/animal points to -Z (the running direction).
const B = preload("res://scripts/Builder.gd")

const TIRE := Color(0.06, 0.06, 0.07)
const GLASS := Color(0.16, 0.24, 0.32)
const CHROME := Color(0.78, 0.8, 0.84)

static func _tilt(p: Node, size: Vector3, pos: Vector3, c: Color, deg_x: float, m: Material = null) -> MeshInstance3D:
	var mi := B.box(p, size, pos, c, m)
	mi.rotation_degrees.x = deg_x
	return mi

static func wheel(p: Node, r: float, wd: float, pos: Vector3) -> void:
	var t := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = wd
	cm.radial_segments = 14
	t.mesh = cm
	t.material_override = B.mat(TIRE)
	t.position = pos
	t.rotation_degrees.z = 90.0
	p.add_child(t)
	var h := MeshInstance3D.new()
	var hm := CylinderMesh.new()
	hm.top_radius = r * 0.55
	hm.bottom_radius = r * 0.55
	hm.height = wd + 0.03
	hm.radial_segments = 10
	h.mesh = hm
	h.material_override = B.mat(CHROME)
	h.position = pos
	h.rotation_degrees.z = 90.0
	p.add_child(h)

static func _lights(n: Node3D, w: float, l: float, y: float) -> void:
	for x in [-1.0, 1.0]:
		B.box(n, Vector3(0.34, 0.18, 0.08), Vector3(x * w * 0.34, y, -l / 2.0 - 0.02), Color.WHITE, B.lamp())
		B.box(n, Vector3(0.34, 0.16, 0.08), Vector3(x * w * 0.34, y, l / 2.0 + 0.02), Color(0.85, 0.05, 0.05))

# ---------------- Vehicles ----------------
static func vehicle(id: String, s: Array, c: Color) -> Node3D:
	match id:
		"taxi": return _car(s, c, true)
		"car": return _car(s, c, false)
		"microbus": return _van(s, c)
		"cng": return _cng(s, c)
		"rickshaw": return _rickshaw(s, c)
		"motorcycle": return _bike(s, c)
		"local_bus", "highway_bus", "city_bus": return _bus(s, c)
		"minibus": return _bus(s, c)
	return null

static func _car(s: Array, c: Color, taxi: bool) -> Node3D:
	var n := Node3D.new()
	var w: float = s[0]
	var l: float = s[2]
	B.box(n, Vector3(w, 0.5, l), Vector3(0, 0.62, 0), c)                       # lower body
	B.box(n, Vector3(w * 0.96, 0.18, l * 0.3), Vector3(0, 0.92, -l * 0.32), c) # hood
	B.box(n, Vector3(w * 0.92, 0.18, l * 0.2), Vector3(0, 0.92, l * 0.4), c)   # boot
	B.box(n, Vector3(w * 0.9, 0.5, l * 0.42), Vector3(0, 1.1, l * 0.04), c)    # cabin
	B.box(n, Vector3(w * 0.9 + 0.03, 0.34, l * 0.4), Vector3(0, 1.12, l * 0.04), GLASS)
	_tilt(n, Vector3(w * 0.86, 0.5, 0.06), Vector3(0, 1.1, -l * 0.17), GLASS, -32.0)
	B.box(n, Vector3(w * 0.8, 0.07, l * 0.4), Vector3(0, 1.38, l * 0.04), c.darkened(0.08))
	B.box(n, Vector3(w + 0.04, 0.2, 0.12), Vector3(0, 0.42, -l / 2.0), Color(0.15, 0.15, 0.17))
	B.box(n, Vector3(w + 0.04, 0.2, 0.12), Vector3(0, 0.42, l / 2.0), Color(0.15, 0.15, 0.17))
	B.box(n, Vector3(w * 0.5, 0.14, 0.06), Vector3(0, 0.62, -l / 2.0 - 0.01), Color(0.1, 0.1, 0.12))
	B.box(n, Vector3(0.4, 0.14, 0.04), Vector3(0, 0.44, l / 2.0 + 0.08), Color(0.95, 0.95, 0.9))
	for x in [-1.0, 1.0]:
		B.box(n, Vector3(0.1, 0.1, 0.18), Vector3(x * (w / 2.0 + 0.05), 1.0, -l * 0.16), c.darkened(0.2))
		for z in [-0.31, 0.31]:
			wheel(n, 0.34, 0.24, Vector3(x * (w / 2.0 - 0.1), 0.34, z * l))
	_lights(n, w, l, 0.66)
	if taxi:
		for i in 6:  # checker band
			B.box(n, Vector3(w + 0.05, 0.1, 0.34), Vector3(0, 0.78, -l * 0.3 + i * 0.34 * (l / 4.2)), Color.BLACK if i % 2 == 0 else Color.WHITE)
		B.box(n, Vector3(0.62, 0.2, 0.28), Vector3(0, 1.52, l * 0.04), Color(1, 0.95, 0.6), B.lamp())
	B.blob(n, w * 1.3, l * 1.15)
	return n

static func _van(s: Array, c: Color) -> Node3D:
	var n := Node3D.new()
	var w: float = s[0]
	var h: float = s[1]
	var l: float = s[2]
	B.box(n, Vector3(w, h - 0.55, l), Vector3(0, 0.55 + (h - 0.55) / 2.0, 0), c)
	B.box(n, Vector3(w + 0.03, 0.42, l * 0.72), Vector3(0, h - 0.5, l * 0.1), GLASS)
	_tilt(n, Vector3(w * 0.9, 0.55, 0.06), Vector3(0, h - 0.55, -l / 2.0 + 0.02), GLASS, -20.0)
	for x in [-1.0, 1.0]:
		for z in [-0.3, 0.3]:
			wheel(n, 0.36, 0.24, Vector3(x * (w / 2.0 - 0.1), 0.36, z * l))
	_lights(n, w, l, 0.7)
	B.blob(n, w * 1.3, l * 1.15)
	return n

static func _cng(s: Array, c: Color) -> Node3D:
	var n := Node3D.new()
	var w: float = s[0]
	var l: float = s[2]
	B.box(n, Vector3(w, 0.55, l * 0.8), Vector3(0, 0.62, l * 0.1), c)
	B.box(n, Vector3(w * 0.9, 0.9, l * 0.55), Vector3(0, 1.3, l * 0.2), Color(0.12, 0.12, 0.13))   # cabin
	B.box(n, Vector3(w * 0.94, 0.12, l * 0.6), Vector3(0, 1.8, l * 0.2), c)                        # roof
	B.box(n, Vector3(w * 0.84, 0.5, 0.05), Vector3(0, 1.45, -l * 0.08), GLASS)
	for x in [-1.0, 1.0]:                                                                          # side cage bars
		for z in [0.0, 0.2, 0.4]:
			B.box(n, Vector3(0.03, 0.8, 0.04), Vector3(x * w * 0.46, 1.3, l * z + 0.05), Color(0.7, 0.7, 0.72))
	B.box(n, Vector3(w * 0.5, 0.5, 0.5), Vector3(0, 0.75, -l * 0.42), c)                           # nose
	wheel(n, 0.3, 0.16, Vector3(0, 0.3, -l * 0.4))
	for x in [-1.0, 1.0]:
		wheel(n, 0.3, 0.16, Vector3(x * (w / 2.0 - 0.05), 0.3, l * 0.32))
	B.box(n, Vector3(0.3, 0.16, 0.08), Vector3(0, 0.85, -l / 2.0 - 0.02), Color.WHITE, B.lamp())
	B.box(n, Vector3(w * 0.9, 0.12, 0.05), Vector3(0, 0.55, l / 2.0 + 0.02), Color(0.85, 0.05, 0.05))
	B.blob(n, w * 1.3, l * 1.15)
	return n

static func _rickshaw(s: Array, c: Color) -> Node3D:
	var n := Node3D.new()
	var l: float = s[2]
	wheel(n, 0.4, 0.07, Vector3(-0.42, 0.4, l * 0.2))
	wheel(n, 0.4, 0.07, Vector3(0.42, 0.4, l * 0.2))
	wheel(n, 0.36, 0.06, Vector3(0, 0.36, -l * 0.38))
	B.box(n, Vector3(0.9, 0.12, 0.9), Vector3(0, 0.62, l * 0.22), c.darkened(0.1))             # passenger floor
	B.box(n, Vector3(0.8, 0.1, 0.45), Vector3(0, 0.8, l * 0.28), Color(0.15, 0.15, 0.18))      # seat
	B.box(n, Vector3(0.8, 0.5, 0.1), Vector3(0, 1.05, l * 0.42), Color(0.15, 0.15, 0.18))      # seat back
	var hood := _tilt(n, Vector3(0.95, 0.07, 0.95), Vector3(0, 1.62, l * 0.2), Color(0.95, 0.2, 0.3), 14.0)
	hood.rotation_degrees.x = 14.0
	for x in [-1.0, 1.0]:
		B.box(n, Vector3(0.06, 0.9, 0.06), Vector3(x * 0.46, 1.1, l * 0.02), Color(0.7, 0.7, 0.72))
		B.box(n, Vector3(0.04, 0.55, 0.7), Vector3(x * 0.47, 0.95, l * 0.28), c)               # painted side panels
		B.box(n, Vector3(0.05, 0.3, 0.4), Vector3(x * 0.48, 1.0, l * 0.28), Color(1, 0.8, 0.2))
	B.box(n, Vector3(0.06, 0.06, l * 0.55), Vector3(0, 0.7, -l * 0.15), Color(0.2, 0.2, 0.22))  # frame
	B.box(n, Vector3(0.12, 0.08, 0.26), Vector3(0, 0.95, -l * 0.2), Color(0.1, 0.1, 0.1))      # driver saddle
	B.box(n, Vector3(0.7, 0.05, 0.05), Vector3(0, 1.15, -l * 0.34), Color(0.7, 0.7, 0.72))     # handlebar
	B.blob(n, 1.2, l * 1.05)
	return n

static func _bike(s: Array, c: Color) -> Node3D:
	var n := Node3D.new()
	var l: float = s[2]
	wheel(n, 0.36, 0.14, Vector3(0, 0.36, -l * 0.34))
	wheel(n, 0.36, 0.16, Vector3(0, 0.36, l * 0.34))
	B.box(n, Vector3(0.3, 0.32, 0.8), Vector3(0, 0.78, -0.05), c)                            # tank/body
	B.box(n, Vector3(0.28, 0.12, 0.65), Vector3(0, 0.98, 0.35), Color(0.1, 0.1, 0.1))        # seat
	B.box(n, Vector3(0.12, 0.3, 0.4), Vector3(0, 0.45, 0.05), Color(0.25, 0.25, 0.28))       # engine
	B.box(n, Vector3(0.7, 0.05, 0.05), Vector3(0, 1.12, -l * 0.28), Color(0.7, 0.7, 0.72))   # handlebar
	var f := B.box(n, Vector3(0.07, 0.8, 0.07), Vector3(0, 0.75, -l * 0.3), Color(0.7, 0.7, 0.72))
	f.rotation_degrees.x = -18.0
	B.box(n, Vector3(0.22, 0.2, 0.1), Vector3(0, 1.0, -l * 0.36), Color.WHITE, B.lamp())
	B.box(n, Vector3(0.2, 0.08, 0.06), Vector3(0, 0.82, l / 2.0), Color(0.85, 0.05, 0.05))
	B.blob(n, 0.8, l * 1.1)
	return n

static func _bus(s: Array, c: Color) -> Node3D:
	var n := Node3D.new()
	var w: float = s[0]
	var h: float = s[1]
	var l: float = s[2]
	B.box(n, Vector3(w, h - 0.5, l), Vector3(0, 0.5 + (h - 0.5) / 2.0, 0), c)
	B.box(n, Vector3(w + 0.03, h * 0.3, l * 0.92), Vector3(0, h * 0.62, l * 0.02), GLASS)           # window band
	for i in int(l / 1.6):
		B.box(n, Vector3(w + 0.05, h * 0.32, 0.07), Vector3(0, h * 0.62, -l / 2.0 + 1.1 + i * 1.6), c.darkened(0.1))
	B.box(n, Vector3(w + 0.04, 0.3, l), Vector3(0, 0.75, 0), c.lightened(0.45))                     # stripe
	B.box(n, Vector3(w * 0.9, h * 0.42, 0.06), Vector3(0, h * 0.58, -l / 2.0 - 0.02), GLASS)        # windscreen
	B.box(n, Vector3(w * 0.6, 0.35, 0.07), Vector3(0, h - 0.2, -l / 2.0 - 0.03), Color(1, 0.85, 0.3), B.lamp())  # destination board
	B.box(n, Vector3(w * 0.9, 0.12, l * 0.9), Vector3(0, h + 0.06, 0), Color(0.75, 0.75, 0.78))     # roof rack
	B.box(n, Vector3(w + 0.1, 0.25, 0.14), Vector3(0, 0.38, -l / 2.0 - 0.04), Color(0.15, 0.15, 0.17))
	for x in [-1.0, 1.0]:
		for z in [-0.3, 0.3]:
			wheel(n, 0.5, 0.3, Vector3(x * (w / 2.0 - 0.15), 0.5, z * l))
	_lights(n, w, l, 0.85)
	B.blob(n, w * 1.2, l * 1.08)
	return n

# ---------------- Animals ----------------
static func _stripe(p: Node, pos: Vector3, h: float) -> void:
	B.box(p, Vector3(0.62, h, 0.07), pos, Color(0.08, 0.05, 0.03))

static func tiger() -> Node3D:
	var n := Node3D.new()
	var o := Color(0.93, 0.48, 0.1)
	var cr := Color(1, 0.92, 0.78)
	var k := Color(0.07, 0.045, 0.03)
	var body := B.capsule(n, 0.46, 1.75, Vector3(0, 1.05, 0.05), o)
	body.rotation_degrees.x = 90
	B.sphere(n, 0.5, Vector3(0, 1.0, -0.55), o).scale = Vector3(1, 1.05, 1.0)               # chest
	B.sphere(n, 0.46, Vector3(0, 1.02, 0.7), o)                                              # haunch
	B.box(n, Vector3(0.62, 0.2, 1.3), Vector3(0, 0.72, 0.05), cr)                           # belly
	for i in 7:
		_stripe(n, Vector3(0, 1.45 - absf(i - 3) * 0.015, -0.55 + i * 0.28), 0.1)
		B.box(n, Vector3(0.07, 0.4, 0.07), Vector3(-0.42, 1.12, -0.55 + i * 0.28), k)
		B.box(n, Vector3(0.07, 0.4, 0.07), Vector3(0.42, 1.12, -0.55 + i * 0.28), k)
	var head := B.sphere(n, 0.4, Vector3(0, 1.28, -1.12), o)
	head.scale = Vector3(1.1, 0.95, 1.0)
	B.sphere(n, 0.2, Vector3(0, 1.14, -1.45), cr).scale = Vector3(1.3, 0.8, 1.2)             # muzzle
	B.box(n, Vector3(0.12, 0.08, 0.06), Vector3(0, 1.22, -1.64), Color(0.9, 0.4, 0.45))     # nose
	B.box(n, Vector3(0.3, 0.05, 0.06), Vector3(0, 1.05, -1.6), k)                            # mouth line
	for x in [-1.0, 1.0]:
		B.sphere(n, 0.12, Vector3(x * 0.3, 1.62, -1.02), o)                                  # ears
		B.sphere(n, 0.07, Vector3(x * 0.3, 1.62, -1.07), k)
		B.sphere(n, 0.075, Vector3(x * 0.17, 1.36, -1.48), Color(1, 0.85, 0.1), B.unshaded(Color(1, 0.85, 0.1)))   # eyes
		B.sphere(n, 0.035, Vector3(x * 0.17, 1.36, -1.54), k)
		B.box(n, Vector3(0.1, 0.22, 0.04), Vector3(x * 0.34, 1.26, -1.28), k)                # cheek stripe
		B.box(n, Vector3(0.28, 0.02, 0.02), Vector3(x * 0.26, 1.12, -1.6), Color(1, 1, 1))   # whiskers
	B.box(n, Vector3(0.5, 0.1, 0.06), Vector3(0, 1.62, -1.1), k)                             # forehead marks
	var tail := B.capsule(n, 0.07, 1.2, Vector3(0, 1.38, 1.7), o)
	tail.rotation_degrees.x = 72
	for t in [0.3, 0.6, 0.85]:
		B.box(n, Vector3(0.17, 0.06, 0.1), Vector3(0, 1.2 + 0.31 * 1.2 * t, 1.1 + 0.95 * 1.2 * t), k)
	var legs: Array = []
	for z in [-0.6, 0.7]:
		for x in [-0.3, 0.3]:
			var pv := Node3D.new()
			pv.position = Vector3(x, 0.9, z)
			n.add_child(pv)
			B.capsule(pv, 0.13, 0.85, Vector3(0, -0.4, 0), o)
			B.sphere(pv, 0.16, Vector3(0, -0.82, -0.03), cr)                                 # paw
			B.box(pv, Vector3(0.18, 0.05, 0.18), Vector3(0, -0.3, 0.0), k)
			legs.append(pv)
	n.set_meta("legs", [legs[0], legs[2], legs[1], legs[3]])
	B.blob(n, 1.6, 3.1)
	return n

static func bear(c: Color) -> Node3D:
	var n := Node3D.new()
	var dark := c.darkened(0.25)
	var body := B.capsule(n, 0.58, 1.6, Vector3(0, 1.0, 0.1), c)
	body.rotation_degrees.x = 90
	B.sphere(n, 0.55, Vector3(0, 1.15, -0.55), c)                                            # shoulders
	B.sphere(n, 0.4, Vector3(0, 1.3, -1.0), c)                                               # head
	B.sphere(n, 0.2, Vector3(0, 1.17, -1.32), Color(0.72, 0.56, 0.36)).scale = Vector3(1, 0.85, 1.2)
	B.sphere(n, 0.06, Vector3(0, 1.22, -1.5), Color(0.03, 0.03, 0.03))
	for x in [-1.0, 1.0]:
		B.sphere(n, 0.13, Vector3(x * 0.28, 1.65, -0.95), c)
		B.sphere(n, 0.07, Vector3(x * 0.28, 1.65, -1.0), dark)
		B.sphere(n, 0.055, Vector3(x * 0.16, 1.38, -1.3), Color(0.03, 0.03, 0.03))
	B.sphere(n, 0.12, Vector3(0, 1.0, 0.95), c)                                              # tail
	for z in [-0.55, 0.7]:
		for x in [-0.34, 0.34]:
			B.capsule(n, 0.17, 0.8, Vector3(x, 0.4, z), dark)
			B.sphere(n, 0.19, Vector3(x, 0.07, z - 0.04), dark)
	B.box(n, Vector3(0.3, 0.05, 0.05), Vector3(0, 1.0, -1.46), Color(0.9, 0.9, 0.85))        # chest patch hint
	return n

static func horse(c: Color) -> Node3D:
	var n := Node3D.new()
	var mane := Color(0.08, 0.05, 0.03)
	var body := B.capsule(n, 0.36, 1.5, Vector3(0, 1.2, 0.05), c)
	body.rotation_degrees.x = 90
	var neck := B.capsule(n, 0.17, 0.95, Vector3(0, 1.75, -0.7), c)
	neck.rotation_degrees.x = 28
	var head := B.capsule(n, 0.14, 0.6, Vector3(0, 2.13, -1.0), c)
	head.rotation_degrees.x = 62
	B.box(n, Vector3(0.14, 0.1, 0.16), Vector3(0, 1.95, -1.27), c.darkened(0.15))
	for x in [-1.0, 1.0]:
		B.box(n, Vector3(0.06, 0.2, 0.06), Vector3(x * 0.1, 2.38, -0.9), c)
		B.sphere(n, 0.035, Vector3(x * 0.12, 2.18, -1.08), Color(0.02, 0.02, 0.02))
	B.box(n, Vector3(0.08, 0.7, 0.2), Vector3(0, 1.98, -0.62), mane).rotation_degrees.x = 28
	var tail := B.capsule(n, 0.06, 0.8, Vector3(0, 1.05, 0.9), mane)
	tail.rotation_degrees.x = -12
	for z in [-0.55, 0.6]:
		for x in [-0.2, 0.2]:
			B.capsule(n, 0.08, 0.95, Vector3(x, 0.5, z), c.darkened(0.2))
			B.box(n, Vector3(0.12, 0.1, 0.14), Vector3(x, 0.05, z), mane)
	B.blob(n, 0.9, 2.2)
	return n

static func cow(c: Color, buffalo: bool = false) -> Node3D:
	var n := Node3D.new()
	var body_c := Color(0.2, 0.18, 0.17) if buffalo else c
	var body := B.capsule(n, 0.42, 1.55, Vector3(0, 1.0, 0), body_c)
	body.rotation_degrees.z = 90
	B.sphere(n, 0.28, Vector3(0.85, 1.12, 0), body_c)                                         # head
	B.box(n, Vector3(0.22, 0.22, 0.3), Vector3(1.05, 1.02, 0), body_c.lightened(0.3))         # muzzle
	for z in [-1.0, 1.0]:
		B.sphere(n, 0.08, Vector3(0.78, 1.26, z * 0.28), body_c.darkened(0.2))                # ears
		var horn := B.capsule(n, 0.035, 0.34, Vector3(0.8, 1.45, z * 0.18), Color(0.9, 0.88, 0.75))
		horn.rotation_degrees.x = z * 25.0
		B.sphere(n, 0.035, Vector3(0.98, 1.2, z * 0.14), Color(0.02, 0.02, 0.02))
	if not buffalo:
		B.sphere(n, 0.18, Vector3(0.45, 1.38, 0), body_c.darkened(0.1)).scale = Vector3(1.2, 0.8, 0.8)   # hump
		B.box(n, Vector3(0.45, 0.4, 0.5), Vector3(-0.1, 1.05, 0.12), Color(0.2, 0.15, 0.12))  # spots
	B.capsule(n, 0.035, 0.7, Vector3(-0.85, 0.95, 0), body_c.darkened(0.2))                   # tail
	for x in [-0.5, 0.55]:
		for z in [-0.2, 0.2]:
			B.capsule(n, 0.075, 0.7, Vector3(x, 0.35, z), body_c.darkened(0.25))
	return n

static func bird() -> Node3D:
	var n := Node3D.new()
	var c := Color(0.96, 0.96, 0.94)
	B.sphere(n, 0.15, Vector3.ZERO, c).scale = Vector3(0.8, 0.75, 1.7)                        # body
	var neck := B.capsule(n, 0.04, 0.3, Vector3(0, 0.1, -0.28), c)
	neck.rotation_degrees.x = 50
	B.sphere(n, 0.06, Vector3(0, 0.2, -0.38), c)
	B.box(n, Vector3(0.035, 0.03, 0.16), Vector3(0, 0.19, -0.5), Color(1, 0.65, 0.1))         # beak
	B.sphere(n, 0.015, Vector3(0.04, 0.22, -0.4), Color.BLACK)
	B.box(n, Vector3(0.12, 0.02, 0.2), Vector3(0, 0.02, 0.3), Color(0.85, 0.85, 0.82))        # tail
	B.box(n, Vector3(0.02, 0.02, 0.3), Vector3(0, -0.08, 0.42), Color(0.3, 0.3, 0.3))         # trailing legs
	var wings: Array = []
	for s in [-1.0, 1.0]:
		var pv := Node3D.new()
		pv.position = Vector3(s * 0.08, 0.06, -0.02)
		n.add_child(pv)
		B.box(pv, Vector3(0.38, 0.02, 0.28), Vector3(s * 0.19, 0, 0.02), c)
		B.box(pv, Vector3(0.3, 0.02, 0.2), Vector3(s * 0.5, 0, 0.06), Color(0.82, 0.82, 0.8))
		B.box(pv, Vector3(0.14, 0.02, 0.12), Vector3(s * 0.74, 0, 0.1), Color(0.25, 0.25, 0.28))
		wings.append(pv)
	n.set_meta("wings", wings)
	return n

# ---------------- Roadside structures ----------------
static func pump_station(p: Node, z: float, label: String) -> void:
	var o := Vector3(0, 0, z)
	B.box(p, Vector3(18, 0.06, 15), o + Vector3(14.5, 0.03, 0), Color(0.55, 0.56, 0.58))     # concrete forecourt
	B.box(p, Vector3(5.0, 0.07, 15), o + Vector3(5.8, 0.04, 0), Color(0.2, 0.2, 0.22))        # driveway
	for dz in [-5.5, 5.5]:
		for dx in [9.5, 16.5]:
			B.cyl(p, 0.16, 0.16, 4.4, o + Vector3(dx, 2.2, dz), Color(0.85, 0.85, 0.88))
	B.box(p, Vector3(9.5, 0.5, 13), o + Vector3(13, 4.5, 0), Color(0.95, 0.95, 0.95))         # canopy
	B.box(p, Vector3(9.6, 0.18, 13.1), o + Vector3(13, 4.3, 0), Color(0.88, 0.12, 0.12))
	B.box(p, Vector3(9.6, 0.18, 13.1), o + Vector3(13, 4.76, 0), Color(0.1, 0.5, 0.25))
	for dz in [-3.0, 3.0]:                                                                    # dispensers
		B.box(p, Vector3(0.9, 1.7, 0.7), o + Vector3(13, 0.9, dz), Color(0.9, 0.12, 0.1))
		B.box(p, Vector3(0.92, 0.5, 0.72), o + Vector3(13, 1.35, dz), Color(0.97, 0.97, 0.97))
		B.box(p, Vector3(0.6, 0.2, 0.05), o + Vector3(12.55, 1.45, dz), Color(0.1, 0.9, 0.4), B.lamp())
		B.box(p, Vector3(0.1, 0.1, 0.4), o + Vector3(12.5, 1.0, dz + 0.45), Color(0.1, 0.1, 0.1))
	B.box(p, Vector3(5.5, 3.4, 8.0), o + Vector3(20.5, 1.7, 0), Color(0.96, 0.93, 0.82))      # shop
	B.box(p, Vector3(5.8, 0.4, 8.3), o + Vector3(20.5, 3.5, 0), Color(0.85, 0.12, 0.12))
	B.box(p, Vector3(0.1, 1.6, 5.5), o + Vector3(17.7, 1.6, 0), Color(0.55, 0.75, 0.85), B.win())
	var sign_pole := B.cyl(p, 0.18, 0.18, 8.0, o + Vector3(5.6, 4.0, -6.0), Color(0.8, 0.8, 0.83))
	sign_pole.name = "pole"
	B.box(p, Vector3(0.4, 3.0, 4.6), o + Vector3(5.6, 8.4, -6.0), Color(0.07, 0.35, 0.2))
	B.box(p, Vector3(0.45, 2.7, 4.3), o + Vector3(5.45, 8.4, -6.0), Color(0.98, 0.82, 0.1), B.lamp())
	var l := B.label3d(p, label, o + Vector3(5.2, 8.4, -6.0), 64)
	l.rotation.y = -PI / 2.0
	l.modulate = Color(0.1, 0.1, 0.1)
	l.outline_size = 0
	var l2 := B.label3d(p, label, o + Vector3(5.2, 8.4, -6.0), 64)
	l2.rotation.y = PI / 2.0
	l2.position.x = 5.95
	l2.modulate = Color(0.1, 0.1, 0.1)
	l2.outline_size = 0

static func toll_plaza(p: Node, z: float, label: String, can_pay: bool = true) -> void:
	var o := Vector3(0, 0, z)
	B.box(p, Vector3(13.5, 0.55, 7.0), o + Vector3(-2.1, 6.3, 0), Color(0.12, 0.2, 0.55))     # canopy roof
	B.box(p, Vector3(13.6, 0.18, 7.1), o + Vector3(-2.1, 6.0, 0), Color(0.98, 0.8, 0.1))
	B.box(p, Vector3(12.6, 1.4, 0.2), o + Vector3(-2.1, 7.4, 3.0), Color(0.05, 0.4, 0.25))   # sign board
	var l := B.label3d(p, label, o + Vector3(-2.1, 7.4, 3.15), 70)
	l.modulate = Color.WHITE
	for x in [-1.1, 1.1, -3.9, 3.7, -5.8, -7.6]:                                              # booth islands
		B.box(p, Vector3(0.9, 3.0, 4.2), o + Vector3(x, 1.5, 0), Color(0.95, 0.85, 0.15))
		B.box(p, Vector3(0.95, 0.5, 4.3), o + Vector3(x, 0.25, 0), Color(0.1, 0.1, 0.12))
		B.box(p, Vector3(0.92, 0.9, 1.6), o + Vector3(x, 2.6, 0), Color(0.5, 0.75, 0.9), B.win())
	for x in [-2.2, 0.0, 2.2, -6.9, -4.9]:                                                    # signals + boom arms
		B.box(p, Vector3(0.7, 0.35, 0.12), o + Vector3(x, 5.5, 3.4), Color(0.1, 0.9, 0.35), B.lamp())
		B.box(p, Vector3(0.7, 0.1, 0.1), o + Vector3(x, 5.8, 3.4), Color.BLACK)
	for x in [-1.1, 1.1]:
		var arm := B.box(p, Vector3(1.9, 0.12, 0.12), o + Vector3(x - 0.9 if x < 0 else x + 0.9, 2.3, 2.0), Color(0.9, 0.1, 0.1))
		arm.rotation_degrees.z = -55.0 if x < 0 else 55.0

static func section_sign(p: Node, z: float, bn: String, en: String) -> void:
	var o := Vector3(5.9, 0, z)
	for dz in [-2.6, 2.6]:
		B.cyl(p, 0.09, 0.09, 4.0, o + Vector3(0, 2.0, dz), Color(0.6, 0.6, 0.63))
	B.box(p, Vector3(0.12, 1.9, 6.4), o + Vector3(0, 4.1, 0), Color(0.04, 0.38, 0.22))
	B.box(p, Vector3(0.14, 1.7, 6.2), o + Vector3(-0.03, 4.1, 0), Color(0.05, 0.45, 0.27))
	var l := B.label3d(p, bn + "\n" + en, o + Vector3(-0.1, 4.1, 0), 52)
	l.rotation.y = -PI / 2.0
	l.line_spacing = -6.0

# ---------------- Railway & train ----------------
static var _train_mesh: ArrayMesh

# Track on the far side of the opposite carriageway (x = -25), one segment long.
static func rails(p: Node, seg_len: float) -> void:
	B.box(p, Vector3(4.2, 0.3, seg_len), Vector3(-25, 0.1, -seg_len / 2.0), Color(0.5, 0.47, 0.43))      # ballast
	for x in [-25.72, -24.28]:
		B.box(p, Vector3(0.14, 0.2, seg_len), Vector3(x, 0.36, -seg_len / 2.0), Color(0.72, 0.74, 0.78))
	var z := -1.0
	while z > -seg_len:
		B.box(p, Vector3(2.5, 0.12, 0.3), Vector3(-25, 0.27, z), Color(0.33, 0.24, 0.17))
		z -= 1.6

# A baked train (loco + coaches) running along Z; the nose points to +Z.
static func train_mesh() -> ArrayMesh:
	if _train_mesh != null:
		return _train_mesh
	var n := Node3D.new()
	var z := 36.0
	# locomotive (blue/orange, like BR diesels)
	B.box(n, Vector3(3.0, 3.4, 15.0), Vector3(0, 2.6, z - 7.5), Color(0.12, 0.35, 0.7))
	B.box(n, Vector3(3.04, 0.9, 15.0), Vector3(0, 1.3, z - 7.5), Color(0.95, 0.55, 0.1))
	B.box(n, Vector3(3.1, 0.2, 15.0), Vector3(0, 3.55, z - 7.5), Color(0.9, 0.9, 0.92))
	B.box(n, Vector3(2.6, 1.0, 0.1), Vector3(0, 3.3, z + 0.02), GLASS)
	for x in [-1.0, 1.0]:
		B.box(n, Vector3(0.2, 0.3, 0.1), Vector3(x * 1.0, 1.4, z + 0.05), Color.WHITE, B.lamp())
		B.box(n, Vector3(0.05, 1.1, 1.4), Vector3(x * 1.54, 3.0, z - 3.0), GLASS)
	B.box(n, Vector3(1.4, 0.5, 4.0), Vector3(0, 4.5, z - 9.0), Color(0.25, 0.25, 0.28))
	_bogies(n, z - 3.0, 3.0)
	_bogies(n, z - 12.0, 3.0)
	# coaches (green/white)
	var cz := z - 16.0
	for i in 5:
		B.box(n, Vector3(3.0, 3.3, 17.0), Vector3(0, 2.55, cz - 8.5), Color(0.1, 0.5, 0.3))
		B.box(n, Vector3(3.04, 0.35, 17.0), Vector3(0, 1.1, cz - 8.5), Color(0.95, 0.95, 0.95))
		B.box(n, Vector3(3.1, 0.18, 17.0), Vector3(0, 4.25, cz - 8.5), Color(0.8, 0.8, 0.82))
		for x in [-1.0, 1.0]:
			for k in 7:
				B.box(n, Vector3(0.06, 1.0, 1.4), Vector3(x * 1.52, 3.0, cz - 1.8 - k * 2.3), GLASS)
		_bogies(n, cz - 3.0, 3.0)
		_bogies(n, cz - 14.0, 3.0)
		cz -= 17.5
	_train_mesh = B.bake(n)
	n.free()
	return _train_mesh

static func _bogies(n: Node3D, z: float, w: float) -> void:
	B.box(n, Vector3(2.4, 0.5, 3.4), Vector3(0, 0.75, z), Color(0.1, 0.1, 0.12))
	for dz in [-1.0, 1.0]:
		wheel(n, 0.5, 0.18, Vector3(-0.72, 0.5, z + dz))
		wheel(n, 0.5, 0.18, Vector3(0.72, 0.5, z + dz))
