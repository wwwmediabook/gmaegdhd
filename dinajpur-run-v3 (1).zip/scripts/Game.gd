extends Node
# Autoload: data, local save, settings, missions, sfx.
const SAVE_PATH := "user://save.json"
const BACKUP_PATH := "user://save_backup.json"
var characters: Array = []
var routes: Array = []
var vehicles: Array = []
var missions: Array = []
var rides: Array = []
var save: Dictionary = {}

const EN := {
	"দিনাজপুর–ঝিনাইদহ": "Dinajpur–Jhenaidah",
	"সেরা স্কোর": "Best score",
	"কয়েন": "Coins",
	"স্কোর": "Score",
	"দূরত্ব": "Distance",
	"খেলুন": "PLAY",
	"অফলাইন": "Offline",
	"অনলাইন": "Online",
	"চরিত্র নির্বাচন": "Choose Character",
	"চরিত্র": "Characters",
	"মানচিত্র": "MAP",
	"মিশন সম্পন্ন": "Mission done",
	"মিশন": "Missions",
	"শপ": "Shop",
	"ক্লাউড / লিডারবোর্ড": "Cloud / Leaderboard",
	"সেটিংস": "Settings",
	"ক্লাউড মেনুতে Cloud URL দিন": "Enter the Cloud URL in the Cloud menu",
	"কয়েন কম আছে!": "Not enough coins!",
	"ছেলে": "BOYS",
	"মেয়ে": "GIRLS",
	"দাম": "Price",
	"নির্বাচিত": "SELECTED",
	"নির্বাচন": "SELECT",
	"আনলক": "UNLOCK",
	"ফিরে যান": "Back",
	"দিক বদলান": "Switch direction",
	"সম্পন্ন": "Done",
	"পুরস্কার": "Reward",
	"রিভাইভ টোকেন কিনুন": "Buy revive token",
	"রিভাইভ টোকেন": "Revive tokens",
	"নতুন চরিত্র কিনতে 'চরিত্র' মেনুতে যান (প্রতিটি 1 COIN)": "Buy new characters in the Characters menu (1 COIN each)",
	"ক্লাউড সেভ মেনু": "Cloud save menu",
	"নিশ্চিত? আবার চাপুন": "Sure? Tap again",
	"লোকাল ব্যাকআপ নেওয়া হয়েছে": "Local backup saved",
	"লোকাল ব্যাকআপ থেকে রিস্টোর হয়েছে": "Restored from local backup",
	"ব্যাকআপ পাওয়া যায়নি": "No backup found",
	"ক্লাউড / অনলাইন": "Cloud / Online",
	"মোড": "Mode",
	"অফলাইনে সব কাজ করে। অনলাইনে ক্লাউড সেভ ও লিডারবোর্ড।": "Everything works offline. Online adds cloud save and leaderboard.",
	"আপনার নাম": "Your name",
	"এখন সিঙ্ক করুন": "Sync now",
	"ক্লাউড থেকে রিস্টোর": "Restore from cloud",
	"লিডারবোর্ড দেখুন": "View leaderboard",
	"লোকাল ব্যাকআপ নিন": "Take local backup",
	"লোকাল ব্যাকআপ থেকে রিস্টোর": "Restore local backup",
	"লিডারবোর্ড": "Leaderboard",
	"অনলাইন মোড চালু করুন এবং ক্লাউড URL দিন।": "Turn on Online mode and enter the Cloud URL.",
	"লোড হচ্ছে...": "Loading...",
	"বিরতি": "PAUSE",
	"চালিয়ে যান": "RESUME",
	"আবার শুরু": "RESTART",
	"চেকপয়েন্ট": "Checkpoint",
	"সেরা": "Best",
	"টোকেন": "Tokens",
	"গন্তব্য": "Destination",
	"সময়": "Time",
	"সেকেন্ড": "sec",
	"উল্টো দিক": "reverse",
	"পুরস্কার: +50 কয়েন": "Reward: +50 coins",
	"ভালোবাসা! +১ রিভাইভ টোকেন": "Love! +1 revive token",
	"বৃষ্টি শুরু হয়েছে!": "It started raining!",
	"অফলাইন মোড": "Offline mode",
	"ক্লাউড URL সেট করা হয়নি (লোকাল সেভ নিরাপদ আছে)": "Cloud URL not set (local save is safe)",
	"ইন্টারনেট নেই / সিঙ্ক ব্যর্থ": "No internet / sync failed",
	"সিঙ্ক সফল": "Sync successful",
	"ক্লাউড URL সেট করা হয়নি": "Cloud URL not set",
	"ক্লাউড থেকে রিস্টোর হয়েছে": "Restored from cloud",
	"ক্লাউডে সেভ পাওয়া যায়নি": "No cloud save found",
	"লিডারবোর্ড পাওয়া যায়নি (ইন্টারনেট/URL দেখুন)": "Leaderboard unavailable (check internet/URL)",
	"সাধারণ": "Normal",
	"ছোট ম্যাগনেট সবসময়": "Small magnet always",
	"পাওয়ার-আপ ১.৫x সময়": "Power-ups last 1.5x",
	"শুরুতে শিল্ড": "Shield at start",
	"মোট ১০০ কয়েন সংগ্রহ করুন": "Collect 100 coins in total",
	"মোট ৩০০০ মিটার দৌড়ান": "Run 3000 meters in total",
	"১০টি চেকপয়েন্ট পার করুন": "Pass 10 checkpoints",
	"৫ বার দৌড় শেষ করুন": "Finish 5 runs",
	"ভাষা": "Language",
	"ডেভলপার": "Developer",
	"এখন": "Now",
	"পরের": "Next",
	"কিমি": "km",
	"গাড়ি": "Vehicle",
	"পেট্রোল": "Fuel",
	"পেট্রোল নিন": "Buy petrol",
	"পেট্রোল শেষ! গাড়ি ছেড়ে হাঁটুন": "Out of petrol! Continue on foot",
	"টোল": "Toll",
	"টোল দিতে পারেননি! গাড়ি আটকে গেছে": "Could not pay the toll! Vehicle stopped",
	"পথচারী: টোল ফ্রি": "On foot: toll free",
	"দুর্ঘটনা! জরিমানা": "Accident! Fine",
	"গাড়ি ভেঙে গেছে": "Vehicle wrecked",
	"উঠেছেন": "boarded",
	"পেট্রোল পাম্প": "PETROL PUMP",
	"টোল প্লাজা": "TOLL PLAZA",
	"ট্যাক্সি": "Taxi",
	"সিএনজি": "CNG",
	"প্রাইভেট কার": "Car",
	"মোটরসাইকেল": "Motorbike",
	"রিকশা": "Rickshaw",
	"বাস": "Bus",
	"আনুমানিক": "approx.",
	"পদ্মা নদী": "Padma River",
	"গুগল ম্যাপে খুলুন": "Open in Google Maps",
	"পেট্রোল ভরা হলো": "Tank filled",
	"পায়ে হেঁটে": "On foot",
	"ট্যাংক": "Tank",
	"শুরু": "START",
	"গন্তব্য স্টেশন": "DESTINATION",
	"খেলার দূরত্ব": "Game distance",
	"মহাসড়ক": "Highway",
	"সড়ক": "Road",
	"জেলা": "District",
	"আপনি এখানে": "You are here",
	"ডেভলপার: Medul": "Developer: Medul",
}

var _loops: Dictionary = {}
var _en_keys: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	characters = _j("res://data/characters.json")
	routes = _j("res://data/routes.json")
	vehicles = _j("res://data/vehicles.json")
	missions = _j("res://data/missions.json")
	rides = _j("res://data/rides.json")
	load_save()
	_en_keys = EN.keys()
	_en_keys.sort_custom(func(a, b): return str(a).length() > str(b).length())
	music_apply()

func _j(p: String) -> Variant:
	return JSON.parse_string(FileAccess.get_file_as_string(p))

func _default() -> Dictionary:
	return {"coins": 5, "unlocked": ["boy_01", "girl_01"], "selected": "boy_01", "best_score": 0,
		"direction": "fwd", "tokens": 2, "claimed": [], "progress": {"fwd": 0, "rev": 0},
		"stats": {"coins": 0, "meters": 0, "cps": 0, "runs": 0}, "updated": 0, "uid": "",
		"settings": {"music": true, "sound": true, "vibration": true, "quality": 1, "fps": 60, "lang": "bn", "cloud_url": "", "online": false, "name": "Player"}}

func load_save() -> void:
	var d := _default()
	if FileAccess.file_exists(SAVE_PATH):
		var p: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
		if p is Dictionary:
			var st: Dictionary = d["settings"]
			st.merge(p.get("settings", {}), true)
			p.erase("settings")
			d.merge(p, true)
	save = d
	if str(save["uid"]) == "":
		save["uid"] = "p%d%d" % [int(Time.get_unix_time_from_system()), randi() % 100000]
		write_save()
	apply_settings()

func write_save() -> void:
	save["updated"] = Time.get_unix_time_from_system()
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(save))

func apply_settings() -> void:
	Engine.max_fps = int(save["settings"]["fps"])

func backup_local() -> void:
	write_save()
	DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)

func restore_local() -> bool:
	if not FileAccess.file_exists(BACKUP_PATH):
		return false
	DirAccess.copy_absolute(BACKUP_PATH, SAVE_PATH)
	load_save()
	return true

func reset_all() -> void:
	save = _default()
	write_save()
	apply_settings()

func char_by_id(id: String) -> Dictionary:
	for c in characters:
		if c["id"] == id:
			return c
	return characters[0]

func is_unlocked(id: String) -> bool:
	return id in save["unlocked"]

func unlock(id: String) -> bool:
	var price: int = int(char_by_id(id)["price"])
	if is_unlocked(id):
		return true
	if int(save["coins"]) < price:
		return false
	save["coins"] = int(save["coins"]) - price
	save["unlocked"].append(id)
	write_save()
	return true

func route_data() -> Dictionary:
	var base: Dictionary = routes[0]
	var stops: Array = base["stops"].duplicate(true)
	var tolls: Array = base.get("tolls", []).duplicate(true)
	var pumps: Array = base.get("pumps", []).duplicate(true)
	var L: float = float(base["length_km"])
	if save["direction"] == "rev":
		stops.reverse()
		for s in stops:
			s["at"] = L - float(s["at"])
		tolls.reverse()
		for tl in tolls:
			tl["at"] = L - float(tl["at"])
		pumps = pumps.map(func(x): return L - float(x))
		pumps.reverse()
	var last: Dictionary = stops[stops.size() - 1]
	return {"dir": save["direction"], "from": stops[0]["name"], "to": last["name"], "from_d": stops[0], "to_d": last,
		"length_km": L, "m_per_km": base["m_per_km"], "stops": stops, "tolls": tolls, "pumps": pumps}

func save_progress(i: int) -> void:
	var p: Dictionary = save["progress"]
	var d: String = save["direction"]
	p[d] = maxi(int(p.get(d, 0)), i)
	write_save()

# Called once when a run ends. Returns newly completed missions.
func end_run(st: Dictionary, completed: bool) -> Array:
	save["coins"] = int(save["coins"]) + int(st["coins"]) + (50 if completed else 0)
	save["best_score"] = maxi(int(save["best_score"]), int(st["score"]))
	var s: Dictionary = save["stats"]
	s["coins"] = int(s["coins"]) + int(st["coins"])
	s["meters"] = int(s["meters"]) + int(st["distance_m"])
	s["cps"] = int(s["cps"]) + int(st["cps"])
	s["runs"] = int(s["runs"]) + 1
	var done: Array = []
	for m in missions:
		if m["id"] in save["claimed"]:
			continue
		if int(s.get(m["type"], 0)) >= int(m["target"]):
			save["claimed"].append(m["id"])
			save["coins"] = int(save["coins"]) + int(m["reward"])
			done.append(m)
	write_save()
	return done

func sfx(n: String, db: float = 0.0) -> void:
	if not save["settings"]["sound"]:
		return
	var p := "res://audio/%s.wav" % n
	if not ResourceLoader.exists(p):
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = load(p)
	pl.volume_db = db
	add_child(pl)
	pl.play()
	pl.finished.connect(pl.queue_free)

func loop_start(n: String, db: float = -6.0) -> void:
	if _loops.has(n):
		return
	var flag: String = "music" if n == "music" else "sound"
	if not save["settings"][flag]:
		return
	var p := "res://audio/%s.wav" % n
	if not ResourceLoader.exists(p):
		return
	var st: AudioStreamWAV = (load(p) as AudioStreamWAV).duplicate()
	st.loop_mode = AudioStreamWAV.LOOP_FORWARD
	st.loop_begin = 0
	st.loop_end = st.data.size() / 2
	var pl := AudioStreamPlayer.new()
	pl.stream = st
	pl.volume_db = db
	add_child(pl)
	pl.play()
	_loops[n] = pl

func loop_stop(n: String) -> void:
	if _loops.has(n):
		_loops[n].queue_free()
		_loops.erase(n)

func music_apply() -> void:
	if save["settings"]["music"]:
		loop_start("music", -12.0)
	else:
		loop_stop("music")

func vibrate() -> void:
	if save["settings"]["vibration"]:
		Input.vibrate_handheld(120)

# ---------------- Language (bn / en) ----------------
func is_en() -> bool:
	return str(save["settings"].get("lang", "bn")) == "en"

# Bangla text -> English when language is English (exact or partial match, longest first).
func t(s: String) -> String:
	if not is_en():
		return s
	if EN.has(s):
		return EN[s]
	var out := s
	for k in _en_keys:
		if out.find(k) != -1:
			out = out.replace(k, EN[k])
	return out

# Name of a route stop / character in the current language.
func nm(d: Dictionary) -> String:
	if is_en() and d.has("en"):
		return str(d["en"])
	return str(d.get("name", ""))

# Bangla digits -> Latin when English.
func num(n: Variant) -> String:
	return str(n)
