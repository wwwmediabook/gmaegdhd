#!/usr/bin/env python3
"""Original synthesized sounds (v5): click, slap, laugh, cry, brake, engine, train, train_horn. Needs numpy."""
import numpy as np, wave, os
SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
rng = np.random.default_rng(5)

def save(name, x, peak=0.85):
    x = np.asarray(x, dtype=np.float64)
    x = x / max(1e-6, np.max(np.abs(x))) * peak
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32000).astype("<i2").tobytes())

def t(d): return np.arange(int(SR * d)) / SR
def lp(x, a):
    y = np.empty_like(x); p = 0.0
    for i, s in enumerate(x):
        p += a * (s - p); y[i] = p
    return y
def env_ad(n, a, d):
    e = np.ones(n); na = max(1, int(a * SR)); e[:na] = np.linspace(0, 1, na)
    e *= np.exp(-d * np.arange(n) / n); return e

def vowel(f0, d, f1, f2, vib=0.0, vibf=6.0):
    tt = t(d); ph = 2 * np.pi * np.cumsum(f0 * (1 + vib * np.sin(2 * np.pi * vibf * tt)) / SR)
    x = np.zeros_like(tt)
    for h in range(1, 30):
        fr = f0 * h
        amp = np.exp(-((fr - f1) / 260.0) ** 2) + 0.6 * np.exp(-((fr - f2) / 380.0) ** 2) + 0.05
        x += amp * np.sin(h * ph) / h ** 0.3
    return x

# click: soft tick
n = t(0.06); x = np.sin(2 * np.pi * 1500 * n) * np.exp(-n * 90) + 0.4 * rng.uniform(-1, 1, len(n)) * np.exp(-n * 160)
save("click", x, 0.6)
# slap: sharp noise crack + body thump
n = t(0.28); crack = lp(rng.uniform(-1, 1, len(n)), 0.7) * np.exp(-n * 38)
thump = np.sin(2 * np.pi * (180 - 400 * n) * n) * np.exp(-n * 18)
save("slap", crack * 1.1 + thump * 0.8)
# laugh: ha-ha-ha-ha, pitch falling
parts = []
for i, f in enumerate([330, 315, 300, 285, 270]):
    v = vowel(f * (1.0 - 0.02 * i), 0.14, 800, 1300) * env_ad(int(SR * 0.14), 0.01, 3.0)
    breath = lp(rng.uniform(-1, 1, len(v)), 0.35) * 0.25 * env_ad(len(v), 0.005, 6)
    parts += [v + breath, np.zeros(int(SR * 0.075))]
x = np.concatenate(parts); save("laugh", x)
# cry: waaah, wavering pitch with vibrato, two swells
d = 1.5; tt = t(d)
f0 = 520 - 120 * tt + 25 * np.sin(2 * np.pi * 7 * tt)
ph = 2 * np.pi * np.cumsum(f0 / SR); x = np.zeros_like(tt)
for h in range(1, 26):
    fr = f0 * h
    amp = np.exp(-((fr - 900 - 250 * np.sin(2 * np.pi * 1.4 * tt)) / 300.0) ** 2) + 0.5 * np.exp(-((fr - 2100) / 500.0) ** 2) + 0.04
    x += amp * np.sin(h * ph) / h ** 0.25
sw = (0.55 + 0.45 * np.sin(2 * np.pi * 1.3 * tt - 1.0)) * np.minimum(1, tt * 30) * np.exp(-1.2 * tt)
sob = lp(rng.uniform(-1, 1, len(tt)), 0.25) * 0.15 * (np.sin(2 * np.pi * 9 * tt) > 0)
save("cry", x * sw + sob * sw)
# brake squeal
d = 0.8; tt = t(d); f = 2400 - 700 * tt
sq = np.sin(2 * np.pi * np.cumsum(f / SR)) * 0.5 + 0.25 * np.sin(2 * np.pi * np.cumsum(f * 1.5 / SR))
gr = lp(rng.uniform(-1, 1, len(tt)), 0.5) * 0.5
save("brake", (sq * (0.7 + 0.3 * rng.uniform(0, 1, len(tt))) + gr) * np.minimum(1, tt * 20) * np.exp(-1.6 * tt), 0.6)
# engine loop (1 s, integer cycles -> seamless)
tt = t(1.0); x = np.zeros_like(tt)
for h, a in [(1, 1), (2, .8), (3, .55), (4, .4), (6, .25), (8, .12)]:
    x += a * np.sin(2 * np.pi * 45 * h * tt)
x *= 0.7 + 0.3 * np.sin(2 * np.pi * 15 * tt)
x += 0.08 * lp(rng.uniform(-1, 1, len(tt)), 0.2)
save("engine", x, 0.55)
# train loop (2 s): rumble + rail clack
tt = t(2.0); x = lp(rng.uniform(-1, 1, len(tt)), 0.05) * 1.6
for k in range(8):
    o = int(SR * k * 0.25); m = int(SR * 0.05)
    x[o:o + m] += (np.sin(2 * np.pi * 220 * t(0.05)) * np.exp(-t(0.05) * 60) + 0.5 * rng.uniform(-1, 1, m) * np.exp(-t(0.05) * 80)) * 0.8
x += 0.35 * np.sin(2 * np.pi * 52 * tt)
save("train", x, 0.7)
# train horn: two-tone chord
tt = t(1.6); x = (np.sin(2 * np.pi * 311 * tt) + 0.7 * np.sin(2 * np.pi * 415 * tt) + 0.3 * np.sin(2 * np.pi * 622 * tt))
x *= np.minimum(1, tt * 12) * np.minimum(1, (1.6 - tt) * 6)
save("train_horn", x, 0.7)
print("ok")
