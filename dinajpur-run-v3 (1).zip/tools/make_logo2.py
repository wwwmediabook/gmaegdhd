#!/usr/bin/env python3
"""BAGH EXPRESS logo (tiger face + road + sunrise). Writes ../icons/*. Needs Pillow."""
import math, os
from PIL import Image, ImageDraw, ImageFilter, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "..", "icons")
S = 1024
FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"

def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def background(size):
    im = Image.new("RGB", (size, size)); d = ImageDraw.Draw(im)
    for y in range(size):
        t = y / (size - 1)
        c = lerp((30, 20, 90), (235, 80, 90), t / .55) if t < .55 else lerp((235, 80, 90), (255, 190, 80), (t - .55) / .45)
        d.line([(0, y), (size, y)], fill=c)
    return im

def tiger(size):
    """Tiger face on transparent canvas."""
    k = size / 1024.0
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx, cy = 512 * k, 470 * k
    o = (247, 135, 22); dk = (38, 20, 10); cr = (255, 238, 205)
    for sx in (-1, 1):  # ears
        ex = cx + sx * 255 * k
        d.ellipse([ex - 105 * k, cy - 330 * k, ex + 105 * k, cy - 120 * k], fill=o, outline=dk, width=int(14 * k))
        d.ellipse([ex - 55 * k, cy - 280 * k, ex + 55 * k, cy - 160 * k], fill=(255, 190, 170))
    d.ellipse([cx - 330 * k, cy - 270 * k, cx + 330 * k, cy + 300 * k], fill=o, outline=dk, width=int(16 * k))   # head
    for sx in (-1, 1):  # cheeks
        d.ellipse([cx + sx * 150 * k - 150 * k, cy + 30 * k, cx + sx * 150 * k + 150 * k, cy + 290 * k], fill=cr)
    for i, (w, h) in enumerate([(70, 160), (50, 130), (40, 100)]):  # stripes
        for sx in (-1, 1):
            x = cx + sx * (275 - i * 18) * k
            y = cy - 20 * k + i * 90 * k
            d.polygon([(x, y), (x - sx * 120 * k, y + h * .35 * k), (x - sx * 10 * k, y + h * .7 * k)], fill=dk)
    for sx in (-1, 1):  # forehead stripes
        for j in (-1, 0, 1):
            x = cx + sx * (60 + j * 12 + 20) * k if j else cx
    d.polygon([(cx - 30 * k, cy - 265 * k), (cx + 30 * k, cy - 265 * k), (cx + 12 * k, cy - 140 * k), (cx - 12 * k, cy - 140 * k)], fill=dk)
    for sx in (-1, 1):
        d.polygon([(cx + sx * 90 * k, cy - 245 * k), (cx + sx * 150 * k, cy - 215 * k), (cx + sx * 95 * k, cy - 140 * k)], fill=dk)
        # eyes
        ex = cx + sx * 135 * k; ey = cy - 30 * k
        d.ellipse([ex - 62 * k, ey - 42 * k, ex + 62 * k, ey + 42 * k], fill=(255, 245, 170), outline=dk, width=int(10 * k))
        d.ellipse([ex - 20 * k, ey - 38 * k, ex + 20 * k, ey + 38 * k], fill=dk)
        d.ellipse([ex - 8 * k, ey - 24 * k, ex + 2 * k, ey - 10 * k], fill=(255, 255, 255))
    d.polygon([(cx - 55 * k, cy + 80 * k), (cx + 55 * k, cy + 80 * k), (cx, cy + 135 * k)], fill=(230, 90, 110), outline=dk)   # nose
    d.line([(cx, cy + 135 * k), (cx, cy + 190 * k)], fill=dk, width=int(12 * k))
    d.arc([cx - 90 * k, cy + 150 * k, cx, cy + 235 * k], 0, 180, fill=dk, width=int(12 * k))
    d.arc([cx, cy + 150 * k, cx + 90 * k, cy + 235 * k], 0, 180, fill=dk, width=int(12 * k))
    for sx in (-1, 1):  # whiskers
        for j in (-1, 0, 1):
            d.line([(cx + sx * 110 * k, cy + 150 * k + j * 22 * k), (cx + sx * 300 * k, cy + 140 * k + j * 55 * k)], fill=(255, 255, 255), width=int(7 * k))
    return im

def road(size):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im); k = size / 1024.0
    d.polygon([(0, size), (size, size), (size * .68, size * .78), (size * .32, size * .78)], fill=(40, 40, 52))
    for i in range(4):
        t = i / 4; y0 = size * (.8 + .2 * t * t); y1 = y0 + size * .05 * (1 + t)
        w0 = size * .012 * (1 + 2 * t)
        d.polygon([(size / 2 - w0, y0), (size / 2 + w0, y0), (size / 2 + w0 * 1.5, y1), (size / 2 - w0 * 1.5, y1)], fill=(255, 214, 80))
    return im

def title(size, small=False):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    f1 = ImageFont.truetype(FONT, int(size * .135)); f2 = ImageFont.truetype(FONT, int(size * .062))
    for txt, f, y, col in [("BAGH", f1, .06, (255, 255, 255)), ("EXPRESS", f2, .835, (255, 224, 120))]:
        w = d.textlength(txt, font=f); x = (size - w) / 2; Y = size * y
        d.text((x + 4, Y + 6), txt, font=f, fill=(20, 10, 40, 220))
        d.text((x, Y), txt, font=f, fill=col, stroke_width=max(2, int(size * .006)), stroke_fill=(30, 12, 50))
    return im

def compose(size, rounded=True, with_text=True):
    bg = background(size).convert("RGBA")
    sun = Image.new("RGBA", (size, size), (0, 0, 0, 0)); sd = ImageDraw.Draw(sun)
    sd.ellipse([size * .2, size * .45, size * .8, size * 1.05], fill=(255, 225, 130, 150))
    bg.alpha_composite(sun.filter(ImageFilter.GaussianBlur(size * .02)))
    bg.alpha_composite(road(size))
    t = tiger(int(size * .8)); bg.alpha_composite(t, (int(size * .1), int(size * .12)))
    if with_text:
        bg.alpha_composite(title(size))
    if rounded:
        m = Image.new("L", (size, size), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], int(size * .2), fill=255)
        bg.putalpha(m)
    return bg

logo = compose(1024)
logo.save(os.path.join(OUT, "logo.png"))
logo.resize((512, 512), Image.LANCZOS).save(os.path.join(OUT, "icon_512.png"))
logo.resize((192, 192), Image.LANCZOS).save(os.path.join(OUT, "icon_192.png"))
splash = Image.new("RGBA", (720, 720), (0, 0, 0, 0)); splash.alpha_composite(logo.resize((640, 640), Image.LANCZOS), (40, 40)); splash.save(os.path.join(OUT, "splash.png"))
background(432).save(os.path.join(OUT, "adaptive_bg_432.png"))
fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0)); fg.alpha_composite(tiger(300), (66, 70)); fg.save(os.path.join(OUT, "adaptive_fg_432.png"))
print("logo ok")
