extends Node
# Optional ONLINE mode. Game works fully offline. Online = cloud save + global leaderboard.
# Backend: any server with the Firebase Realtime Database REST style (URL + "/players/<id>.json").
# Setup (free): Firebase console -> Realtime Database -> Rules: {".read": true, ".write": true} (test mode)
# -> copy the database URL (https://xxxx-default-rtdb.firebaseio.com) into the in-game Cloud screen.
var status := "অফলাইন মোড"

func _base() -> String:
	var u: String = str(Game.save["settings"].get("cloud_url", "")).strip_edges()
	while u.ends_with("/"):
		u = u.left(u.length() - 1)
	return u

func online_enabled() -> bool:
	return bool(Game.save["settings"].get("online", false)) and _base() != ""

func _req(method: int, path: String, body: String = "") -> Array:
	var http := HTTPRequest.new()
	http.timeout = 12.0
	add_child(http)
	var err := http.request(_base() + path, ["Content-Type: application/json"], method, body)
	if err != OK:
		http.queue_free()
		return [0, 0, PackedStringArray(), PackedByteArray()]
	var res: Array = await http.request_completed
	http.queue_free()
	return res

func _ok(res: Array) -> bool:
	return int(res[1]) >= 200 and int(res[1]) < 300

func sync() -> void:
	if _base() == "":
		status = "ক্লাউড URL সেট করা হয়নি (লোকাল সেভ নিরাপদ আছে)"
		return
	Game.write_save()
	var uid: String = str(Game.save["uid"])
	var res: Array = await _req(HTTPClient.METHOD_PUT, "/players/%s.json" % uid, JSON.stringify(Game.save))
	if not _ok(res):
		status = "ইন্টারনেট নেই / সিঙ্ক ব্যর্থ"
		return
	var entry := {"name": str(Game.save["settings"]["name"]), "best": int(Game.save["best_score"])}
	await _req(HTTPClient.METHOD_PUT, "/scores/%s.json" % uid, JSON.stringify(entry))
	status = "সিঙ্ক সফল"

func restore() -> void:
	if _base() == "":
		status = "ক্লাউড URL সেট করা হয়নি"
		return
	var res: Array = await _req(HTTPClient.METHOD_GET, "/players/%s.json" % str(Game.save["uid"]))
	var d: Variant = JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())
	if _ok(res) and d is Dictionary and d.has("coins"):
		var keep_url: String = _base()
		Game.save.merge(d, true)
		Game.save["settings"]["cloud_url"] = keep_url
		Game.write_save()
		status = "ক্লাউড থেকে রিস্টোর হয়েছে"
	else:
		status = "ক্লাউডে সেভ পাওয়া যায়নি"

func fetch_scores() -> Array:
	var out: Array = []
	var res: Array = await _req(HTTPClient.METHOD_GET, "/scores.json")
	var d: Variant = JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())
	if not _ok(res) or not (d is Dictionary):
		status = "লিডারবোর্ড পাওয়া যায়নি (ইন্টারনেট/URL দেখুন)"
		return out
	for k in d:
		var e: Variant = d[k]
		if e is Dictionary and e.has("best"):
			out.append({"name": str(e.get("name", "?")), "best": int(e["best"])})
	out.sort_custom(func(a, b): return a["best"] > b["best"])
	return out.slice(0, 10)
