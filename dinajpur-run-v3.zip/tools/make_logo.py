#!/usr/bin/env python3
"""Draws the game logo + launcher icons into ../icons. Run: python3 tools/make_logo.py (needs Pillow)"""
import math, os, random
from PIL import Image, ImageDraw, ImageFilter, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "..", "icons"); os.makedirs(OUT, exist_ok=True)
S = 2048

def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def gradient(top, mid, bot, h, w):
    im = Image.new("RGB", (w, h)); d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / (h - 1); c = lerp(top, mid, t / .6) if t < .6 else lerp(mid, bot, (t - .6) / .4); d.line([(0, y), (w, y)], fill=c)
    return im

def palm(d, x, base, h, lean, col):
    pts = [(x + lean * (t ** 2) * h, base - t * h) for t in [i / 14 for i in range(15)]]
    for i in range(len(pts) - 1): d.line([pts[i], pts[i + 1]], fill=col, width=int(36 - 20 * i / 14))
    tx, ty = pts[-1]
    for a in range(-170, 11, 30):
        r = math.radians(a); L = h * .5; ex, ey = tx + math.cos(r) * L, ty + math.sin(r) * L * .45 + L * .35
        cx, cy = tx + math.cos(r) * L * .55, ty + math.sin(r) * L * .6 - L * .12
        left, right = [], []
        for i in range(13):
            t = i / 12; bx = (1 - t) ** 2 * tx + 2 * (1 - t) * t * cx + t ** 2 * ex; by = (1 - t) ** 2 * ty + 2 * (1 - t) * t * cy + t ** 2 * ey
            w = 30 * (1 - t) ** .6 * (0.6 + 0.4 * math.sin(math.pi * min(1, t * 1.3)))
            left.append((bx, by - w)); right.append((bx, by + w))
        d.polygon(left + right[::-1], fill=col)

def runner(d, cx, y, k=1.0, col=(255, 255, 255), outline=(25, 25, 60)):
    def P(dx, dy): return (cx + dx * k, y + dy * k)
    limbs = [[(10, -370), (-10, -210)], [(5, -350), (110, -290), (170, -360)], [(5, -350), (-70, -300), (-135, -225)],
             [(-10, -210), (110, -130), (92, -10)], [(-10, -210), (-100, -130), (-205, -60)]]
    for width, c in ((78 * k, outline), (52 * k, col)):
        for l in limbs:
            pts = [P(*p) for p in l]
            d.line(pts, fill=c, width=int(width), joint="curve")
            for p in pts: d.ellipse([p[0] - width / 2, p[1] - width / 2, p[0] + width / 2, p[1] + width / 2], fill=c)
        r = 62 * k + (14 * k if c == outline else 0); hx, hy = P(30, -445)
        d.ellipse([hx - r, hy - r, hx + r, hy + r], fill=c)

def scene(rounded=True, with_runner=True, text=False, size=1024):
    W = S; H = S
    im = gradient((18, 28, 84), (214, 84, 112), (255, 176, 66), 1200, W).resize((W, 1200)).convert("RGBA")
    base = Image.new("RGBA", (W, H), (0, 0, 0, 255)); base.paste(im, (0, 0))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(glow)
    gd.ellipse([1024 - 520, 1140 - 520, 1024 + 520, 1140 + 520], fill=(255, 210, 110, 150)); glow = glow.filter(ImageFilter.GaussianBlur(90))
    base = Image.alpha_composite(base, glow); d = ImageDraw.Draw(base)
    d.ellipse([1024 - 330, 1140 - 330, 1024 + 330, 1140 + 330], fill=(255, 226, 130))
    d.ellipse([1024 - 270, 1140 - 270, 1024 + 270, 1140 + 270], fill=(255, 240, 170))
    random.seed(5)
    for lay, (col, amp, yb) in enumerate([((56, 70, 120), 90, 1190), ((30, 62, 70), 70, 1215)]):
        pts = [(0, 1260)] + [(x, yb - amp * (0.5 + 0.5 * math.sin(x / 210 + lay * 2)) - random.randint(0, 14)) for x in range(0, W + 60, 60)] + [(W, 1260)]
        d.polygon(pts, fill=col)
    d.rectangle([0, 1215, W, H], fill=(46, 120, 52))
    for y in range(1215, H, 6):
        t = (y - 1215) / (H - 1215); d.line([(0, y), (W, y)], fill=lerp((86, 160, 70), (28, 92, 44), t))
    vx, vy = 1024, 1215
    d.polygon([(vx - 14, vy), (vx + 14, vy), (W * .93, H), (W * .07, H)], fill=(40, 40, 46))
    d.polygon([(vx - 14, vy), (vx - 10, vy), (W * .07, H), (W * .07 - 40, H)], fill=(235, 235, 230))
    d.polygon([(vx + 10, vy), (vx + 14, vy), (W * .93 + 40, H), (W * .93, H)], fill=(235, 235, 230))
    for i in range(9):
        t0, t1 = (i / 9) ** 1.8, ((i + .45) / 9) ** 1.8; y0, y1 = vy + (H - vy) * t0, vy + (H - vy) * t1
        w0, w1 = 4 + 34 * t0, 4 + 34 * t1; d.polygon([(vx - w0, y0), (vx + w0, y0), (vx + w1, y1), (vx - w1, y1)], fill=(255, 205, 60))
    palm(d, 330, 1500, 620, 0.22, (14, 40, 30)); palm(d, 1740, 1480, 560, -0.25, (14, 40, 30)); palm(d, 560, 1330, 380, 0.2, (22, 56, 40)); palm(d, 1520, 1320, 360, -0.2, (22, 56, 40))
    if with_runner:
        for i in range(4): d.line([(1024 - 330 - i * 40, 1440 + i * 70), (1024 - 190 - i * 40, 1440 + i * 70)], fill=(255, 255, 255), width=10)
        runner(d, 1024, 1860, 1.35)
    if text:
        f1 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 190)
        f2 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 118)
        for txt, f, y, c in (("DINAJPUR", f1, 150, (255, 255, 255)), ("JHENAIDAH  RUN", f2, 370, (255, 214, 90))):
            w = d.textlength(txt, font=f)
            d.text(((W - w) / 2 + 6, y + 8), txt, font=f, fill=(10, 10, 40)); d.text(((W - w) / 2, y), txt, font=f, fill=c)
    out = base.resize((size, size), Image.LANCZOS)
    if rounded:
        m = Image.new("L", (size * 4, size * 4), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, size * 4 - 1, size * 4 - 1], radius=int(size * .9), fill=255)
        out.putalpha(m.resize((size, size), Image.LANCZOS))
    return out

scene(True, True, True, 1024).save(os.path.join(OUT, "logo.png"))
emblem = scene(True, True, False, 512); emblem.save(os.path.join(OUT, "icon_512.png")); emblem.resize((192, 192), Image.LANCZOS).save(os.path.join(OUT, "icon_192.png"))
scene(False, False, False, 432).convert("RGB").save(os.path.join(OUT, "adaptive_bg_432.png"))
fg = Image.new("RGBA", (S, S), (0, 0, 0, 0)); fd = ImageDraw.Draw(fg); runner(fd, 1024, 1500, 1.5)
sun = Image.new("RGBA", (S, S), (0, 0, 0, 0)); sd = ImageDraw.Draw(sun); sd.ellipse([1024 - 380, 760 - 380, 1024 + 380, 760 + 380], fill=(255, 226, 130, 255)); fg = Image.alpha_composite(sun, fg)
fg.resize((432, 432), Image.LANCZOS).save(os.path.join(OUT, "adaptive_fg_432.png"))
sp = Image.new("RGBA", (720, 720), (0, 0, 0, 0)); sp.alpha_composite(scene(True, True, True, 720)); sp.save(os.path.join(OUT, "splash.png"))
print("logo/icons written")
