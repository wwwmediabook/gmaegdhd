#!/usr/bin/env python3
"""Generates .glb models (10 characters + road segment) into ../models. Run: python3 tools/make_models.py
These are low-poly placeholders that follow the game's naming convention. Replace any file with a real
glb of the same name (see README) and the game will use it automatically."""
import struct, json, math, zlib, os, random
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "models")
random.seed(3)

def box(sx, sy, sz):
    h = (sx / 2, sy / 2, sz / 2)
    faces = [((1,0,0),(0,1,0),(0,0,1)), ((-1,0,0),(0,0,1),(0,1,0)), ((0,1,0),(0,0,1),(1,0,0)),
             ((0,-1,0),(1,0,0),(0,0,1)), ((0,0,1),(1,0,0),(0,1,0)), ((0,0,-1),(0,1,0),(1,0,0))]
    V, N, UV, I = [], [], [], []
    for n, u, v in faces:
        eu = abs(sum(u[i] * h[i] for i in range(3))); ev = abs(sum(v[i] * h[i] for i in range(3)))
        c = [n[i] * h[i] for i in range(3)]
        base = len(V)
        for su, sv, a, b in [(-1,-1,0,0),(1,-1,1,0),(1,1,1,1),(-1,1,0,1)]:
            V.append(tuple(c[i] + su * eu * u[i] + sv * ev * v[i] for i in range(3)))
            N.append(n); UV.append((a * 2 * eu * .25, b * 2 * ev * .25))
        I += [base, base+1, base+2, base, base+2, base+3]
    return V, N, UV, I

def lathe(profile, seg=14):
    V, N, UV, I = [], [], [], []
    for (r, y, nr, ny) in profile:
        for j in range(seg + 1):
            a = 2 * math.pi * j / seg
            V.append((r * math.cos(a), y, r * math.sin(a))); N.append((nr * math.cos(a), ny, nr * math.sin(a))); UV.append((j / seg, y))
    S = seg + 1
    for i in range(len(profile) - 1):
        for j in range(seg):
            a, b, c, d = i*S+j, (i+1)*S+j, (i+1)*S+j+1, i*S+j+1
            I += [a, b, c, a, c, d]
    return V, N, UV, I

def sphere(R, rings=10):
    return lathe([(R*math.sin(math.pi*k/rings), -R*math.cos(math.pi*k/rings), math.sin(math.pi*k/rings), -math.cos(math.pi*k/rings)) for k in range(rings+1)])

def capsule(R, H, rings=5):
    L = max(H - 2*R, 0.0); p = []
    for k in range(rings + 1):
        t = (math.pi / 2) * k / rings
        p.append((R*math.sin(t), -L/2 - R*math.cos(t), math.sin(t), -math.cos(t)))
    for k in range(rings + 1):
        t = math.pi/2 + (math.pi / 2) * k / rings
        p.append((R*math.sin(t), L/2 - R*math.cos(t), math.sin(t), -math.cos(t)))
    return lathe(p)

def cylinder(rt, rb, h):
    L = math.hypot(rt - rb, h); nr, ny = h / L, (rb - rt) / L
    return lathe([(0,-h/2,0,-1),(rb,-h/2,0,-1),(rb,-h/2,nr,ny),(rt,h/2,nr,ny),(rt,h/2,0,1),(0,h/2,0,1)])

def qx(deg):
    a = math.radians(deg) / 2; return (math.sin(a), 0, 0, math.cos(a))

class GLB:
    def __init__(s):
        s.bin = bytearray(); s.bv = []; s.acc = []; s.meshes = []; s.mats = []; s.mk = {}; s.nodes = []; s.imgs = []; s.tex = []
    def _view(s, data, target=None):
        while len(s.bin) % 4: s.bin.append(0)
        d = {"buffer": 0, "byteOffset": len(s.bin), "byteLength": len(data)}
        if target: d["target"] = target
        s.bin += data; s.bv.append(d); return len(s.bv) - 1
    def _acc(s, view, ct, count, typ, mn=None, mx=None):
        a = {"bufferView": view, "componentType": ct, "count": count, "type": typ}
        if mn is not None: a["min"] = mn; a["max"] = mx
        s.acc.append(a); return len(s.acc) - 1
    def image(s, png):
        v = s._view(png); s.imgs.append({"bufferView": v, "mimeType": "image/png"})
        s.tex.append({"source": len(s.imgs) - 1, "sampler": 0}); return len(s.tex) - 1
    def material(s, name, rgb, rough=0.85, tex=None):
        key = (name, tuple(rgb), tex)
        if key in s.mk: return s.mk[key]
        pbr = {"baseColorFactor": [rgb[0], rgb[1], rgb[2], 1.0], "metallicFactor": 0.0, "roughnessFactor": rough}
        if tex is not None: pbr["baseColorTexture"] = {"index": tex}
        s.mats.append({"name": name, "pbrMetallicRoughness": pbr}); s.mk[key] = len(s.mats) - 1; return s.mk[key]
    def part(s, name, geom, mat, t=None, q=None, sc=None):
        V, N, UV, I = geom
        pv = b"".join(struct.pack("<3f", *p) for p in V); nv = b"".join(struct.pack("<3f", *p) for p in N)
        uv = b"".join(struct.pack("<2f", *p) for p in UV); iv = b"".join(struct.pack("<I", i) for i in I)
        mn = [min(p[i] for p in V) for i in range(3)]; mx = [max(p[i] for p in V) for i in range(3)]
        a0 = s._acc(s._view(pv, 34962), 5126, len(V), "VEC3", mn, mx); a1 = s._acc(s._view(nv, 34962), 5126, len(V), "VEC3")
        a2 = s._acc(s._view(uv, 34962), 5126, len(V), "VEC2"); a3 = s._acc(s._view(iv, 34963), 5125, len(I), "SCALAR")
        s.meshes.append({"primitives": [{"attributes": {"POSITION": a0, "NORMAL": a1, "TEXCOORD_0": a2}, "indices": a3, "material": mat}]})
        return s.node(name, len(s.meshes) - 1, t, q, sc)
    def node(s, name, mesh=None, t=None, q=None, sc=None, ch=None):
        n = {"name": name}
        if mesh is not None: n["mesh"] = mesh
        if t is not None and any(t): n["translation"] = list(t)
        if q: n["rotation"] = list(q)
        if sc: n["scale"] = list(sc)
        if ch: n["children"] = ch
        s.nodes.append(n); return len(s.nodes) - 1
    def save(s, path, roots):
        j = {"asset": {"version": "2.0", "generator": "make_models.py"}, "scene": 0, "scenes": [{"nodes": roots}], "nodes": s.nodes,
             "meshes": s.meshes, "materials": s.mats, "accessors": s.acc, "bufferViews": s.bv, "buffers": [{"byteLength": len(s.bin)}]}
        if s.imgs:
            j["images"] = s.imgs; j["textures"] = s.tex
            j["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        js = json.dumps(j, separators=(",", ":")).encode(); js += b" " * ((4 - len(js) % 4) % 4)
        b = bytes(s.bin) + b"\0" * ((4 - len(s.bin) % 4) % 4)
        data = struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(js) + 8 + len(b)) + struct.pack("<I4s", len(js), b"JSON") + js + struct.pack("<I4s", len(b), b"BIN\0") + b
        os.makedirs(os.path.dirname(path), exist_ok=True); open(path, "wb").write(data)

def character(d, path):
    """Modular 'puzzle' character: every body part is its own named node (Head, Torso, ArmL>ElbowL, LegL>KneeL ...)."""
    g = GLB(); M = lambda nm, c, r=0.8: g.material(nm, c, r)
    skin, shirt, pants, hair, shoes = d["skin"], d["shirt"], d["pants"], d["hair"], d["shoes"]
    outfit, style = d.get("outfit", "pants"), d.get("hair_style", "short")
    SK = M("skin", skin, 0.55); SKD = M("skin_dark", [c * .85 for c in skin], 0.55); HR = M("hair", hair, 0.55)
    WH = M("white", (1, 1, 1), 0.3); DK = M("dark", (0.05, 0.05, 0.05), 0.3)
    ch = []
    def P(*a, **k): ch.append(g.part(*a, **k))
    P("Torso", capsule(0.3, 1.0), M("shirt", shirt), (0, 1.15, 0), sc=(1, 1, 0.7))
    P("Neck", cylinder(0.09, 0.1, 0.14), SK, (0, 1.62, 0))
    hd = []
    def H(*a, **k): hd.append(g.part(*a, **k))
    H("Skull", sphere(0.27), SK, (0, 0, 0))
    for s_ in (-1, 1):
        H("Ear", sphere(0.06), SK, (s_ * 0.27, 0, 0))
        H("EyeWhite", sphere(0.06), WH, (s_ * 0.1, 0.05, -0.22), sc=(1, 1.1, 0.5))
        H("Pupil", sphere(0.032), DK, (s_ * 0.1, 0.05, -0.255))
        H("Brow", box(0.1, 0.02, 0.02), HR, (s_ * 0.1, 0.14, -0.24))
    H("Nose", sphere(0.04), SKD, (0, -0.04, -0.27))
    H("Mouth", box(0.11, 0.025, 0.02), M("mouth", (0.75, 0.15, 0.15)), (0, -0.12, -0.25))
    H("Hair", sphere(0.285), HR, (0, 0.12, 0.06), sc=(1, 0.7, 1))
    if style == "long": H("HairLong", capsule(0.17, 0.75), HR, (0, -0.24, 0.2))
    elif style == "ponytail": H("Ponytail", capsule(0.07, 0.55), HR, (0, -0.04, 0.33), q=qx(-35))
    elif style == "bun": H("Bun", sphere(0.13), HR, (0, 0.34, 0.05))
    elif style == "cap":
        cc = M("cap", d.get("cap", shirt))
        H("CapDome", sphere(0.3), cc, (0, 0.17, 0.05), sc=(1, 0.65, 1)); H("CapBrim", box(0.3, 0.03, 0.22), cc, (0, 0.15, -0.3))
    ch.append(g.node("Head", None, (0, 1.84, 0), ch=hd))
    if outfit == "dress": P("Dress", cylinder(0.22, 0.45, 0.6), M("shirt", shirt), (0, 0.82, 0))
    elif outfit == "panjabi": P("Panjabi", cylinder(0.3, 0.37, 0.95), M("shirt", shirt), (0, 0.95, 0))
    for s_, nm in ((-1, "L"), (1, "R")):
        shin = [g.part("Shin", capsule(0.09, 0.4), M("pants", pants), (0, -0.19, 0)),
                g.part("Foot", box(0.2, 0.1, 0.34), M("shoes", shoes), (0, -0.36, -0.06)),
                g.part("Sole", box(0.21, 0.03, 0.35), M("sole", [c * .5 for c in shoes]), (0, -0.42, -0.06))]
        knee = g.node("Knee" + nm, None, (0, -0.4, 0), ch=shin)
        thigh = g.part("Thigh", capsule(0.11, 0.42), M("pants", pants), (0, -0.2, 0))
        ch.append(g.node("Leg" + nm, None, (s_ * 0.15, 0.78, 0), ch=[thigh, knee]))
        fore = [g.part("ForeArm", capsule(0.07, 0.36), SK, (0, -0.17, 0)), g.part("Hand", sphere(0.09), SK, (0, -0.38, 0)),
                g.part("Thumb", sphere(0.04), SK, (-s_ * 0.08, -0.36, -0.04))]
        elbow = g.node("Elbow" + nm, None, (0, -0.38, 0), ch=fore)
        upper = g.part("UpperArm", capsule(0.08, 0.4), M("shirt", shirt), (0, -0.2, 0))
        ch.append(g.node("Arm" + nm, None, (s_ * 0.4, 1.5, 0), ch=[upper, elbow]))
    root = g.node("Character", ch=ch); g.save(path, [root])

def png(w, h, px):
    raw = b"".join(b"\0" + bytes(c for x in range(w) for c in px[y][x]) for y in range(h))
    def chunk(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")

def asphalt_png(n=256):
    # 8 m tile. v (columns) maps x = v*8 - 3.8 ; wheel tracks of the 3 lanes are darker/smoother.
    px = [[None] * n for _ in range(n)]
    low = [[random.uniform(-9, 9) for _ in range(8)] for _ in range(8)]
    tracks = [-2.9, -1.5, -0.7, 0.7, 1.5, 2.9, -5.56, -4.16, -7.59, -6.19]
    for y in range(n):
        for x in range(n):
            xm = y / n * 8 - 7.9 + 8
            v = 66 + low[y * 8 // n][x * 8 // n] + random.uniform(-13, 13)
            for t in tracks:
                tt = (t + 7.9) % 8
                dd = min(abs(y / n * 8 - tt), 8 - abs(y / n * 8 - tt))
                v -= 9 * math.exp(-(dd / 0.22) ** 2)
            if random.random() < 0.025: v += random.uniform(25, 60)
            px[y][x] = v
    for _ in range(7):  # cracks
        x, y = random.randrange(n), random.randrange(n)
        for _ in range(random.randint(25, 70)):
            x = (x + random.choice((-1, 0, 1))) % n; y = (y + random.choice((0, 1, 1))) % n; px[y][x] -= 38
    for _ in range(4):  # patches / oil stains
        cx, cy, r = random.randrange(n), random.randrange(n), random.randint(8, 22)
        for y in range(cy - r, cy + r):
            for x in range(cx - r, cx + r):
                if (x - cx) ** 2 + (y - cy) ** 2 < r * r: px[y % n][x % n] -= 14
    img = [[(int(max(18, min(150, v))),) * 2 + (int(max(18, min(150, v))) + 3,) for v in row] for row in px]
    return png(n, n, img)

def road(path, kind):
    """Two-way road: our 3 lanes (x -3.3..3.3), double yellow line at x~-3.7, 2 oncoming lanes to x=-7.9."""
    g = GLB(); tex = g.image(asphalt_png()); ch = []
    asph = g.material("asphalt", (1, 1, 1), 0.9, tex); white = g.material("paint", (0.9, 0.9, 0.84), 0.75)
    yellow = g.material("paint_y", (0.95, 0.75, 0.1), 0.75)
    ag = box(11.6, 0.12, 40); ag = (ag[0], ag[1], [(u / 2, v / 2) for u, v in ag[2]], ag[3])
    ch.append(g.part("Asphalt", ag, asph, (-2.1, -0.04, -20)))
    for x in (-3.55, -3.85): ch.append(g.part("DoubleYellow", box(0.1, 0.01, 40), yellow, (x, 0.025, -20)))
    for x in (-1.1, 1.1):
        for k in range(5): ch.append(g.part("Dash", box(0.12, 0.01, 2.4), white, (x, 0.025, -4 - 8 * k)))
    for k in range(5): ch.append(g.part("DashOnc", box(0.12, 0.01, 2.4), white, (-5.87, 0.025, -4 - 8 * k)))
    for x in (3.5, -7.7): ch.append(g.part("Edge", box(0.14, 0.01, 40), white, (x, 0.025, -20)))
    if kind == "city":
        kerb = g.material("kerb", (0.66, 0.66, 0.63), 0.9); walk = g.material("sidewalk", (0.56, 0.54, 0.5), 0.9)
        for xk, xs in ((3.9, 4.7), (-8.1, -8.9)):
            ch.append(g.part("Kerb", box(0.4, 0.27, 40), kerb, (xk, 0.035, -20)))
            ch.append(g.part("Sidewalk", box(1.2, 0.27, 40), walk, (xs, 0.035, -20)))
    else:
        dirt = g.material("dirt", (0.46, 0.35, 0.22), 0.98); grass = g.material("verge", (0.32, 0.5, 0.2), 0.98)
        for xs, xv, xp in ((4.2, 5.0, 3.95), (-8.4, -9.2, -8.15)):
            ch.append(g.part("Shoulder", box(1.0, 0.11, 40), dirt, (xs, -0.04, -20)))
            ch.append(g.part("Verge", box(0.6, 0.1, 40), grass, (xv, -0.045, -20)))
            for k in range(10): ch.append(g.part("Post", box(0.1, 0.55, 0.1), white, (xp, 0.25, -2 - 4 * k)))
    g.save(path, [g.node("Road_" + kind, ch=ch)])

if __name__ == "__main__":
    chars = json.load(open(os.path.join(HERE, "..", "data", "characters.json"), encoding="utf-8"))
    for c in chars: character(c, os.path.join(OUT, "characters", c["id"] + ".glb"))
    road(os.path.join(OUT, "road", "road_village.glb"), "village")
    road(os.path.join(OUT, "road", "road_city.glb"), "city")
    print("models written to", os.path.abspath(OUT))
